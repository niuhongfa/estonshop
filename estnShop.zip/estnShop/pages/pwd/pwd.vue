<!-- 忘记密码 -->
<template>
    <view class="body">
        <view class="mainarea">
           <view class="discripe">找回密码</view>
           <view class="user"> 
                <text class="iicol iconfont icon-wode"></text>
                <input type="text" placeholder="请输入账号" name="username" maxlength="11" class="iicot" v-model="user">
            </view>
             <view class="pass">
                <text class="iicol iconfont  icon-shouji"></text>
                <input type="text" placeholder="请输入手机号" name="phone" class="iictv" maxlength="18" v-model="phone">
            </view>
            <view class="pass">
                <text class="iicoll iconfont icon-shimingrenzheng"></text>
                <input type="text" placeholder="请输入验证码" name="verify" class="iictv" maxlength="18" v-model="verify">
                <button class="verification">获取验证码</button>
            </view>

            <view class="pass">
                <text class="iicol iconfont icon-xiugaimima"></text>
                <input type="password" placeholder="请输入新密码" name="password" class="iict" maxlength="18" v-model="newpassword">
                <text class="iicz iconfont icon-biyan"></text>
           </view>

            <button type="primary" class="login" @tap="findpass">提交</button> 
        </view>
        <navigator class="register" url="../login/login">
            记得密码？&nbsp去登录
        </navigator>
    </view>
</template>
<!--  type="primary" class="primary" @tap="findPassword" -->
<script>
    import service from '../../service.js';

    export default {
        components: {
        },
        data() {
            return {
                user: '',
                phone: '',
                verify: '',
                newpassword: ''
            }
        },
        methods: {
            findpass(){},
            findPassword() {
                uni.setStorage({
                    key: this.phone,
                    data: {
                        user: this.user,
                        phone: this.phone,
                        pass: this.newpassword,
                    }
                }),
                uni.showToast({
                    icon: 'none',
                    title: '已发送重置邮件至注册邮箱，请注意查收。',
                    duration: 3000
                });
            }
        }
    }
</script>

<style>
    .body {
        width: 750upx;
        height: 1246upx;
        box-sizing: border-box;
        padding: 140upx 65upx 0;
        background-color: orangered;
    }
    .body>.mainarea {
        width: 620upx;
        height: 810upx;
        box-sizing: border-box;
        background-color: #fff;
        border-radius: 25upx;
        padding-top: 40upx;
    }
    .body>.register {
        width: 250upx;
        height: 50upx;
        font-size: 28upx;
        color: white; 
        text-align: center;
        margin: 70upx 0 0 185upx;
    }
    .login {
        width: 440upx;
        height:64upx;
        margin-top: 80upx;
        background-color: #C63F1A;
        line-height: 64upx;
    }
    .discripe {
        width: 160upx;
        height: 50upx;
        font-size: 40upx;
        font-weight: 700;
        text-align: center;
        margin: 0 auto;
    }
    .user {
        width:480upx;
        height:120upx;
        display:flex;
        margin: 40upx auto 0;
        border-bottom: 2upx solid #ccc;
    }
    .iicol {
        width: 60upx;
        height: 60upx;
        margin: auto 10upx;
        margin-left: 0;
        font-size: 60upx;
    }
    .user>.iicot {
        width: 390upx;
        height: 60upx;
        margin: auto 0;
        box-sizing: border-box;
        padding-left: 10upx;
    }
    .pass {
        width:480upx;
        height:120upx;
        margin: 0 auto;
        display:flex;
        border-bottom: 2upx solid #ccc;
    }
    .pass>.iict {
        width: 340upx;
        height: 60upx;
        margin: auto 0;
        margin-right: 10upx;
        padding-left: 10upx;
    }
    .pass>.iicz {
         width: 60upx;
        height: 60upx;
        box-sizing: border-box;
        margin-top: 40upx;
        padding-left: 10upx;
        font-size: 40upx; 
    }
     .iicoll {
        width: 60upx;
        box-sizing: box-sizing;
        height: 60upx;
        margin: auto 0upx;
        margin-right: 10upx;
        font-size: 50upx;
    }
    .iictv {
        width:215upx;
        height:60upx;
        margin: auto 0;
        margin-right: 10upx;
        box-sizing: border-box;
        padding-left: 10upx;
        font-size:35upx;
    }
    .verification {
        width:190upx;
        height:60upx;
        line-height: 60upx;
        margin-top: 30upx;
        padding: 0;
        font-size: 32upx;
        color: red;
        background-color: #fff;
    }
</style>
