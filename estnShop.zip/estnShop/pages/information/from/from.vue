<template>
	<view class="body" ref="rrr">
		<view class="fromcontent" >
			<view class="msgtop">{{ fromlist.from }}</view>
			<view class="modelcontent " ref="eee">
				<view class="listl" >
					<view class="fromm"></view>
					<view class="sendm">
						<view class="content">
						   jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
						</view>
					</view>
				</view>
				<button @click="acac">点我</button>
				<view class="listr" >
					<view class="sendm">
						<view class="content">
							jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
							 jsdhkflhsfjkdsjfksfsfdsf<br>
							jsdhkflhsfjkdsjfksfsfdsf<br>
						</view>
					</view>
					<view class="fromm">
					</view>
				</view>
			</view>
			<view class="sendmsg">
				<view class="voice iconfont icon-yuyin"></view>
				<view class="views">
					<input type="view" v-model="msg" class="input"/>
					<view class="iico iconfont icon-smile"></view>
				</view>
				<view class="files iconfont icon-jia"></view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				fromlist: "",
				msglist:'',
				mymsg:'',
				msg: ''
			}
		},
		watch:{},
		computed: {},
		methods: {
			getfrom(){
				let ilist = this.$store.state.informationfromlist.find(item =>{
					if(item.id === this.$route.query.id){
						return item
					}
				})
				this.fromlist = ilist;
				this.msglist = ilist.msg;
				let mlist = this.$store.state.informationsendlist.find(item =>{
					if(item.id === this.$route.query.id){
						return item
					}
				})
				this.mymsg = mlist.msg;
			},
			acac(){
				/**
				 * 1 先完善发送信息的功能
				 * 2 完善后进行 this.$ref.name.$el.style.height
				 * this.$refs.name.$el.style.pageY
				 * 监听 pagey的变化动态的改变body的高度 别无他法
				 * 如果成功 则完善首页的加载功能
				 * 如果失败 不写了 跳过去 留给经理 
				 * 
				 */
				this.$refs.rrr.$el.style.height="7000px"
				console.log(this.$refs.rrr.$el.style.height)
				console.log(this.$refs.eee.$el.style.height)
			}
		},
		onLoad: function(e){
			this.getfrom();
			console.log(this.msglist)
			console.log(this.mymsg)
		}
	}
</script>

<style>
	.body {
		width: 750upx;
		height: auto;
		background-color: #EEE;
		padding-bottom: 1000upx;
	}
	.fromcontent {
		width: 750upx;
		min-height: 100%;
		height: auto;
		position: relative;
	}
	.msgtop {
		width: 750upx;
		height: 80upx;
		text-align: center;
		line-height: 80upx;
		font-size: 34upx;
		background-color: #fff;
	}
	.modelcontent {
		width: 750upx;
		height:auto;
	}
	.sendmsg {
		width: 750upx;
		height: 100upx;
		box-sizing: border-box;
		display: flex;
		position:fixed;
		bottom: 0;
		left: 0;
		background-color: #fff;
	}
	.voice {
		width: 70upx;
		height: 70upx;
		margin: 15upx;
		border-radius: 50%;
		view-align: center;
		line-height: 70upx;
		font-size: 55upx;
		color: #222;
		font-weight: 590;
	}
	.views {
		width: 590upx;
		height: 80upx;
		margin-top: 10upx;
		background-color: #EEE;
		border-radius: 40upx;
		display: flex;
		box-sizing: border-box;
	}
	.views .input {
		width: 450upx;
		height: 50upx;
		margin: 15upx 15upx;
		font-size: 36upx;
		color: #222;
	}
	.views .iico {
		width: 60upx;
		height: 60upx;
		font-size: 60upx;
		margin: 10upx;
		border-radius: 50%;
		color: #222;
	}
	.files {
		width: 70upx;
		height: 70upx;
		margin: 15upx;
		border-radius: 50%;
		text-align: center;
		line-height: 70upx;
		font-size: 55upx;
		color: #222;
		font-weight: 550;
	}
	.modelcontent .listl{
		max-width: 650upx;
		min-height: 100upx;
		margin-bottom: 40upx;
		box-sizing: content-box;
		display: flex;
		position: relative;		
	}
	.modelcontent .listl .fromm {
		width: 70upx;
		height: 70upx;
		border-radius: 50%;
		background-color: #238e68;
		margin: 15upx 15upx;
	}
	.modelcontent .listl .sendm {
		max-width: 550upx;
		min-height: 70upx;
		background-color: #ff00ff;
		border-radius: 40upx;
	}
	.modelcontent .listr{
		max-width: 650upx;
		min-height: 100upx;
		height: auto;
		margin-left: 100upx;
		margin-bottom: 40upx;
		box-sizing: content-box;
		display: flex;
		position: relative;
	}
	.modelcontent .listr .fromm {
		width: 70upx;
		height: 70upx;
		border-radius: 50%;
		background-color: #238e68;
		margin: 15upx 15upx;
		position: absolute;
		right: 0upx;
		top: 0;
	}
	.modelcontent .listr .sendm {
		max-width: 550upx;
		min-height: 70upx;
		background-color: #ff00ff;
		border-radius: 40upx;
		position: absolute;
		right: 100upx;
		top: 0;
	}
	.content {
		min-width: 70upx;
		max-width: 550upx;
		min-height: 60upx;
		height: auto;
		background-color: #fff;
		border-radius: 35upx;
	}
	.sendm {
		margin-top: 35upx;

	}
</style>
