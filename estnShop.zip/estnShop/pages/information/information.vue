<template>
	<view class='body'>
		<!-- @click="dellist(item.id)" 删除时写入-->
		<view class='informationlist'v-for="item in informationfromlist" :key="item.id" @click="tofrom(item.id)">
			<view class="msg1">
				<image class="image" :src="item.url"></image>
			</view>
			<view class="msg2">
				<view class="remark">{{ item.from }}</view>
				<view class="message">{{ item.msg[0] }}</view>
			</view>
			<view class="msg3">{{ item.ctime }}</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				informationfromlist: "",
				informationsendlist: ""
			}
		},
		methods: {
			tofrom(id){
				uni.navigateTo({
                    url: 'from/from?id='+id
                });
			},
			dellist(id) {
				this.$store.commit("delFromInformation",id);
			}
		},
		onLoad: function(e) {
			this.informationfromlist = this.$store.state.informationfromlist;
			this.informationsendlist = this.$store.state.informationsendlist;
		}
	}
</script>

<style>
	* {
		padding: 0;
		margin: 0;
	}
	.body {
		background-color: #fff;
	}
	.informationlist {
		width: 750upx;
		height: 102upx;
		box-sizing:border-box;
		padding-left: 20upx;
		border-bottom: 2upx solid #EEE;
		display: flex;
	}
	.msg1 {
		width: 100upx;
		height: 100upx;
		box-sizing: border-box;
		padding: 10upx;
		margin-right: 10upx;
	}
	.msg1 .image {
		width: 80upx;
		height: 80upx;
		background-color: orange;
		border-radius: 50%;
	}
	.msg2 {
		width: 500upx;
		height: 100upx;
		box-sizing: border-box;
		padding-top: 15upx;
	}
	.remark {
		width: 100%;
		height: 40upx;
		font-size: 26upx;
	}
	.message {
		width: 100%;
		height: 40upx;
		font-size: 24upx;
		color: #B9B9B9;
	}
	.msg3 {
		width: 120upx;
		height: 100upx;
		box-sizing: border-box;
		font-size: 26upx;
		line-height: 100upx;
		text-align: center;
		color: #B9B9B9;
	}
</style>
