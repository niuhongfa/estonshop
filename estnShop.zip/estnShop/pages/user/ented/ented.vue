<template>
	<view>
		<view class="ttop">
			<view class="back iconfont icon-fanhui" @click="goback"></view>
			<view class="title">我的管理</view>
			<view class="manage" @click="tomain">返回首页</view>
		</view>
		<view class="main">
			<view class="one" :key="mlist.id">
				<image class="image" :src="mlist.url"></image>
				<view class="mo1">{{ allv }}视频</view>
				<view class="mo1">{{ alla }}张图</view>
				<view class="mo1">{{ count }}点赞</view>
			</view>
			<view class="two">
				<view class="name">{{mlist.name}}</view>
				<view class="mt1">作品</view>
				<view class="mt1">视频</view>
				<view class="mt1">音频</view>
				<view class="mt1">文章</view>
			</view>
			<view class="three">查看账号详情</view>
		</view>
		<view class="middle">
			<view class="title">
				<view class="one" @click="changelist(0)">作品一</view>
				<view class="two" @click="changelist(1)">作品二</view>
				<view class="three" @click="changelist(2)">作品三</view>
			</view>
			<view class="span" :style="{transform:translateX}"></view>
			<view class="alll">
			<view class="list" :style="{transform:translatex}">
				<!-- zuopin1 -->
				<view class="listl" v-for="item in mslist" :key="item.id">
					<view class="content" >
						<view class='one'>
							<video class="videol" :src="item.image[0].url1"></video>
						</view>
						<image class="two" :src="item.image[1].url2"></image>
						<image class="two" :src="item.image[2].url3"></image>
					</view>
					<view class="footer">
						<view class="one">作品简介</view>
						<view class="two">{{ item.image[0].url1 }}
						</view>

					</view>
				</view>
			</view>
			</view>
		</view>
		<view class="bottom">我要发布</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				id:"",
				clist:[
					{
						"id":"1","pid":"1","usenum":"1242849166","name":"大海","url":"../../../static/img/qq.png","allcount":"100","allv":"2","alla":"6"
					},
					{
						"id":"2","pid":"2","usenum":"16639766677","name":"小海","url":"../../../static/img/weixin.png","allcount":"200","allv":"3","alla":"6"
					},
					{
						"id":"3","pid":"3","usenum":"1234567890","name":"地中海","url":"../../../static/img/sinaweibo.png","allcount":"400","allv":"6","alla":"6"
					}
				],
				slist:[
					{
						"id":"1","aid":"1","lid":"1","video":"","image":[{"url1":"../../../static/video/01fuxi.mp4"},{"url2":"../../../static/images/muwu.jpg"},{"url3":"../../../static/images/yuantiao.jpg"}],"title":"落马坡","descripe":"","count":"40"
					},
					{
						"id":"2","aid":"1","lid":"2","video":"","image":[{"url1":"../../../static/video/01fuxi.mp4"},{"url2":"../../../static/images/muwu.jpg"},{"url3":"../../../static/images/yuantiao.jpg"}],"title":"大海的啥","descripe":"","count":"60"
					},
					{
						"id":"3","aid":"2","lid":"1","video":"","image":[{"url1":"../../../static/video/01fuxi.mp4"},{"url2":"../../../static/images/muwu.jpg"},{"url3":"../../../static/images/yuantiao.jpg"}],"title":"挺好的马儿","descripe":"来自名画家李大白之手,传达大家的长生经验1","count":"20"
					},
					{
						"id":"4","aid":"2","lid":"2","video":"","image":[{"url":"../../../static/video/01fuxi.mp4"},{"url":"../../../static/images/muwu.jpg"},{"url":"../../../static/images/yuantiao.jpg"}],"title":"就这吧","descripe":"来自名画家李大白之手,传达大家的长生经验2","count":"50"
					},
					{
						"id":"5","aid":"2","lid":"3","video":"","image":[{"url1":"../../../static/video/01fuxi.mp4"},{"url2":"../../../static/images/muwu.jpg"},{"url3":"../../../static/images/yuantiao.jpg"}],"title":"眼前的啥子","descripe":"来自名画家李大白之手,传达大家的长生经验333333333333333333333333333333333333333333333333333333333333333333333333333","count":"130"
					}
				],
				mlist:{},
				mslist:[],
				allv: 0,
				alla: 0,
				count: 0,
				current:0,
				translateX:"",
				translatex:""
			}
		},
		computed:{

		},
		methods: {
			goback() {
				uni.navigateBack(1)
			},
			tomain(){
				uni.switchTab({
                    url: "/pages/main/main"
                });
			},
			changelist(index){
				this.current = index;
				this.translatex=`
				translateX(-${this.current*uni.upx2px(750)}px)
				`;
				this.translateX=`
				translateX(${this.current*uni.upx2px(190)}px)
				`;

				console.log(index)
				console.log(this.translatex+"====="+this.translateX)
			},
			getlist(){
				this.mlist = this.clist.find(item => {
					if (parseInt(this.id) === parseInt(item.pid)) {
						return item
					}
				})
				this.slist.filter(item => {
					if(parseInt(this.id) === parseInt(item.aid)){
						this.mslist.push(item)
					}
				})
				this.mslist.filter(item => {
					console.log(item.image)
				})
			},
			
		},
		onLoad(option){
			this.id = option.id;
			this.getlist();
			console.log(this.mlist);
		}
	}
</script>

<style>
	*{
		margin: 0;
		padding: 0;
	}
/*头部*/
	.ttop {
		width:750upx;
		height:90upx;
		box-sizing: border-box;
		padding-top: 15upx;
		display: flex;
		border-bottom: 2upx solid #EAEAEA;
	}
	.ttop .back {
		width:60upx;
		height: 60upx;
		text-align: center;
		line-height: 60upx;
		font-weight: 700;
		margin-right: 200upx;
		font-size: 40upx;
	}
	.ttop .title{
		width:200upx;
		height: 60upx;
		font-size: 32upx;
		font-weight: 550;
		margin-right: 130upx;
		text-align: center;
		line-height: 60upx;
	}
	.ttop .manage {
		width:130upx;
		height: 60upx;
		line-height: 60upx;
		color: #222;
		font-size: 30upx;
	}
/*个人*/
	.main {
		width: 750upx;
		height: 340upx;
		background-color: #C65131;
		padding: 35upx 45upx;
		padding-right: 0;
		box-sizing: border-box;
		border-top: 15upx solid #EEE;
	}
	.main>.one{
		display: flex;
		width: 710upx;
		height: 160upx;
		box-sizing: border-box;
	}
	.image{
		width: 160upx;
		height: 160upx;
		background-color: pink;
		margin-right: 50upx;
	}
	.mo1{
		margin-top: 75upx;
		width: 180upx;
		height: 70upx;
		color: #F3E0DC;
		font-size: 34upx;
		font-weight: 550;
	}
	.mo1:last-child{
		width:130upx;
	}
	.main>.two{
		display: flex;
		width: 690upx;
		height: 70upx;
		box-sizing: border-box;
		margin-bottom: 10upx;
	}
	.name{
		width: 160upx;
		height: 70upx;
		line-height: 70upx;
		text-align: left;
		font-size: 34upx;
		font-weight: 700;
		color: #F3E0DC;
		margin-right: 30upx;
	}
	.mt1{
		width: 100upx;
		height: 60upx;
		border: 1upx solid #FFF;
		margin-left: 20upx;
		border-radius: 10upx;
		line-height: 60upx;
		text-align: center;
		font-size: 24upx;
		color: #F3E0DC;
	}
	.main>.three{
		width: 190upx;
		height: 43upx;
		background-color: #853A25;
		border-radius: 23upx;
		font-size: 26upx;
		color: #BFC0BF;
		line-height: 43upx;
		text-align: center;
	}
/*作品*/
	.middle {
		width: 710upx;
		min-height: 600upx;
		height: auto;
		margin: 20upx;
		border-radius: 15upx;
		box-sizing: border-box;
		padding: 0upx 35upx;
		position: relative;
		margin-bottom:100upx;
	}
	.title{
		width: 630upx;
		height: 80upx;
		background-color: #fff;
		display: flex;
		box-sizing: border-box;
		padding-left: 70upx;
	}
	.title>.one{
		width: 120upx;
		height: 80upx;
		font-size: 30upx;
		margin-right: 70upx;
		color: #999;
		line-height: 80upx;
		text-align: center;
	}
	.title>.two{
		width: 120upx;
		height: 80upx;
		font-size: 30upx;
		margin-right: 70upx;
		color: #999;
		line-height: 80upx;
		text-align: center;
	}
	.title>.three{
		width: 120upx;
		height: 80upx;
		font-size: 30upx;
		color: #999;
		line-height: 80upx;
		text-align: center;
	}
	.span{
		width: 120upx;
		height: 5upx;
		background-color: #C65131;
		position: absolute;
		left: 110upx;
		top: 75upx;
		-webkit-transition: all .3s;
		transition: all .3s;
		display: block;
	}
	.alll{
		width: 630upx;
		overflow: hidden
	}
	.list{
		width:300%;
		height: auto;
		display: flex;
		flex-wrap: nowrap;
		margin-bottom:1upx;
		-webkit-transition: all .3s;
		transition: all .3s;
	}
	.listl{
		width: 630upx;
		height:auto;
		box-sizing: border-box;
		margin-left: 0upx;
		margin-right:120upx;
	}
	.listl .content{
		width: 630upx;
		min-height: 360upx;
		height: auto;
		margin-top: 14upx;
		background-color: #fff;
	}
	.listl .content .one{	 	
		width: 610upx;
		height: 360upx;
		border-radius: 20upx;
		background-color: #0ff;
		margin-bottom: 15upx;
	}
	.listl .content .one video{	 	
		width: 100%;
		height: 100%;
		border-radius: 20upx;
		background-color: #0ff;
		margin-bottom: 15upx;
	}
	.listl .content .two{
		width: 610upx;
		height: 520upx;
		border-radius: 20upx;
		margin-bottom: 15upx
	}
/*文脚*/
	.footer{
		width: 590upx;
		height: 220upx;
		background-color: #fff;
		font-size: 28upx;
		box-sizing: border-box;
		margin: 20upx;
	}
	.footer>.one{
		width: 590upx;
		height: 80upx;
		font-size: 30upx;
		font-weight: 700;
		color: #5C5C5C;
		line-height: 80upx
	}
	.footer>.two{
		max-height:135upx;
		width:590upx;
		color: #A7A6A6;
	}
/*页脚*/
	.bottom {
		width: 750upx;
		height: 80upx;
		text-align: center;
		line-height: 80upx;
		color: #fff;
		font-size: 32upx;
		background-color: #C75434;
		margin-bottom: 200upx;

	}
</style>
