<template>
	<view class="body">
		<view class="maxtop">
			<view class="tabBar">
				<view class="tabs" v-for="item,index in TabList" :key="index" @click="tabsChange(index)">
					<view class='tablist'>{{ item.title }}</view>
				</view>
			</view>
			<view class='scrollv' :style="{transform:translateX}"></view>
		</view>
		<view class="tabcon" :style="{transform: translatex}" @touchstart="touchStart" @touchmove="touchMove" @touchend="touchEnd">
			<view class="listcontent">
				<view class="shoplist">
					<view class="listtop">
						<view class="bianhao">
							&nbsp&nbsp订单编号&nbsp:&nbsp&nbsp20190532101421</view>
						<view class="time">2019-09-16</view>
					</view>
					<view class="listmiddle">
						<image class="image" src=""></image>
						<view class="discripe">
							<view class="title">戈壁之行</view>
							<view class="standard">行书/20×33cm/2018</view>
							<view class="price">￥8888</view>
						</view>
					</view>
					<view class="listbottom">
						<view class='status'>订单状态&nbsp:&nbsp&nbsp待付款</view>
						<view class="btn">立即付款</view>
					</view>
				</view>
				<view class="shoplist">
					<view class="listtop">
						<view class="bianhao">
							&nbsp&nbsp订单编号&nbsp:&nbsp&nbsp20190532101421</view>
						<view class="time">2019-09-16</view>
					</view>
					<view class="listmiddle">
						<image class="image" src=""></image>
						<view class="discripe">
							<view class="title">戈壁之行</view>
							<view class="standard">行书/20×33cm/2018</view>
							<view class="price">￥8888</view>
						</view>
					</view>
					<view class="listbottom">
						<view class='status'>订单状态&nbsp:&nbsp&nbsp已付款</view>
						<view class="btn">提醒发货</view>
					</view>
				</view>
				<view class="shoplist">
					<view class="listtop">
						<view class="bianhao">
							&nbsp&nbsp订单编号&nbsp:&nbsp&nbsp20190532101421</view>
						<view class="time">2019-09-16</view>
					</view>
					<view class="listmiddle">
						<image class="image" src=""></image>
						<view class="discripe">
							<view class="title">戈壁之行</view>
							<view class="standard">行书/20×33cm/2018</view>
							<view class="price">￥8888</view>
						</view>
					</view>
					<view class="listbottom">
						<view class='status'>订单状态&nbsp:&nbsp&nbsp已签收</view>
						<view class="btn">去评价</view>
					</view>
				</view>
				<view class="shoplist">
					<view class="listtop">
						<view class="bianhao">
							&nbsp&nbsp订单编号&nbsp:&nbsp&nbsp20190532101421</view>
						<view class="time">2019-09-16</view>
					</view>
					<view class="listmiddle">
						<image class="image" src=""></image>
						<view class="discripe">
							<view class="title">戈壁之行</view>
							<view class="standard">行书/20×33cm/2018</view>
							<view class="price">￥8888</view>
						</view>
					</view>
					<view class="listbottom">
						<view class='status'>订单状态&nbsp:&nbsp&nbsp已发货</view>
						<view class="btn">确认收货</view>
					</view>
				</view>
			</view>
<!-- 待付款 -->
			<view class="listcontent">
				<view class="shoplist">
					<view class="listtop">
						<view class="bianhao">
							&nbsp&nbsp订单编号&nbsp:&nbsp&nbsp20190532101421</view>
						<view class="time">2019-09-16</view>
					</view>
					<view class="listmiddle">
						<image class="image" src=""></image>
						<view class="discripe">
							<view class="title">戈壁之行</view>
							<view class="standard">行书/20×33cm/2018</view>
							<view class="price">￥8888</view>
						</view>
					</view>
					<view class="listbottom">
						<view class='status'>订单状态&nbsp:&nbsp&nbsp已签收</view>
						<view class="btn">去评价</view>
					</view>
				</view>
			</view>
<!-- 待发货 -->
			<view class="listcontent">
				<view class="shoplist">
					<view class="listtop">
						<view class="bianhao">
							&nbsp&nbsp订单编号&nbsp:&nbsp&nbsp20190532101421</view>
						<view class="time">2019-09-16</view>
					</view>
					<view class="listmiddle">
						<image class="image" src=""></image>
						<view class="discripe">
							<view class="title">戈壁之行</view>
							<view class="standard">行书/20×33cm/2018</view>
							<view class="price">￥8888</view>
						</view>
					</view>
					<view class="listbottom">
						<view class='status'>订单状态&nbsp:&nbsp&nbsp已付款</view>
						<view class="btn">提醒发货</view>
					</view>
				</view>
			</view>
<!-- 待收货 -->
			<view class="listcontent">
				<view class="shoplist">
					<view class="listtop">
						<view class="bianhao">
							&nbsp&nbsp订单编号&nbsp:&nbsp&nbsp20190532101421</view>
						<view class="time">2019-09-16</view>
					</view>
					<view class="listmiddle">
						<image class="image" src=""></image>
						<view class="discripe">
							<view class="title">戈壁之行</view>
							<view class="standard">行书/20×33cm/2018</view>
							<view class="price">￥8888</view>
						</view>
					</view>
					<view class="listbottom">
						<view class='status'>订单状态&nbsp:&nbsp&nbsp已发货</view>
						<view class="btn">确认收货</view>
					</view>
				</view>
			</view>
<!-- 待评价 -->
			<view class="listcontent">
				<view class="shoplist">
					<view class="listtop">
						<view class="bianhao">
							&nbsp&nbsp订单编号&nbsp:&nbsp&nbsp20190532101421</view>
						<view class="time">2019-09-16</view>
					</view>
					<view class="listmiddle">
						<image class="image" src=""></image>
						<view class="discripe">
							<view class="title">戈壁之行</view>
							<view class="standard">行书/20×33cm/2018</view>
							<view class="price">￥8888</view>
						</view>
					</view>
					<view class="listbottom">
						<view class='status'>订单状态&nbsp:&nbsp&nbsp已签收</view>
						<view class="btn">去评价</view>
					</view>
				</view>
			</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		components:{
	    },
		data() {
			return {
				startX:0,//开始触摸的位置
                moveX:0,//滑动时的位置
                endX:0,//结束触摸的位置
                disX:0,//移动距离  
				current:0,
				slideEffect:"",
				translateX: '',
				translatex: '',
	            TabList:[
	                {title:'全部'},
	                {title:'待付款'},
	                {title:'待发货'},
	                {title:'待收货'},
	                {title:'待评价'}
	            ]
			}
		},
		components:{
		},
		watch:{
		},
		methods: {
			toback(){
				uni.navigateBack(1)
			},
			tabsChange(index){
	            this.current = index;
	            //解释看下方
	            this.translateX = `translateX(${this.current*uni.upx2px(750/5)}px)`;
	            this.translatex = `translateX(-${this.current*uni.upx2px(750)}px)`
	        },
	        touchStart (e) {
                this.startX = e.touches[0].clientX;
            },
            touchMove (e) {
                this.moveX = e.touches[0].clientX;
                this.disX = this.moveX-this.startX;
                if(this.current == 0){
                	if(this.disX>0 || this.disX == 0) {
	                	this.current = this.current - 1 
	                	this.translatex = `translateX(0px)`
	                }
                }
                if(this.current == 4){
                	if(this.disX<0 || this.disX == 0) {
	                	this.current = this.current - 1 
	                	this.translatex = `translateX(-${this.current*uni.upx2px(750)}px)`
	                }
                }
                if(this.disX<0 || this.disX == 0) {
                	this.current = this.current - 1 
                	this.translatex = `translateX(-${this.current*uni.upx2px(750)}px)`
                }else if(this.disX>0){
                	this.current = this.current + 1 
                	this.translatex = `translateX(${this.current*uni.upx2px(750)}px)`
                }
            },
            touchEnd (e){
            	let endX = e.changedTouches[0].clientX;
                this.disX = endX-this.startX;
                if(this.disX < (375/2)) {
                    this.translatex = 'translateX(0px)';
                }else {
                    this.translatex = "translateX("+ 375+ "px)";
                }

            }
		}
	}
	/**
	 * uni.upx2px() 这一步很重要
	 * upx 行内式无效 所以这里 upx 转 px 输出来达到 自适应
	 *
	 * 四中状态 四种标识 待付款1 代发货2 待收货3 待评价4 
	 * 总标识            全部订单 0
	 */
</script>
 
<style>
	* {
		margin: 0;
		padding: 0;}
	body{
		width:750upx;
		position:relative;
		overflow: auto;
		overflow-scrolling: touch;
        -webkit-overflow-scrolling: touch;
	}
	.maxtop{
		height: 90upx;
		width: 750upx;
		border-top: 25upx solid #EEE;
		position:relative;
		position: fixed;
		top: 80;
		left: 0;
		right: 0;
		z-index: 999;
	}
	.tabBar {
		width: 750upx;
		height: 90upx;
		background-color: #0ff;
		display: flex;
	}
	.tabs {
		width: 750upx;
		height: 90upx;
	}
	.tabs .tablist {
		width: 150upx;
		height: 100%;
		text-align: center;
		line-height: 90upx;
		font-size: 30upx;
	}
	.scrollv {
		width: 100upx;
		height: 4upx;
		background-color: #ff4d6c;
		margin:0 25upx;
		position:absolute;
		bottom: 6upx;
		left: 0;
		transition: all .5s;
	}
	.listcontent {
		width: 750upx;
		height: 400upx;
	}
	.shoplist {
		width: 750upx;
		height: 430upx;
		box-sizing: border-box;
		padding-right: 25upx;
		padding-left: 25upx;
		padding-top: 6upx;
		border-top: 20upx solid #eee;
	}
	.shoplist:last-child{
		padding-right:0; 
	}
	.listtop {
		width: 700upx;
		height: 70upx; /* 400-12 388-70 */
		display: flex;
		border-bottom: 0.5upx solid #eee;
	}
	.bianhao {
		height: 70upx;
		width: 470upx;
		margin-right: 50upx;
		font-size: 24upx;
		color: #C7C7C7;
		box-sizing: border-box;
		padding-left: 15upx;
		line-height: 70upx;
	}
	.time {
		height: 70upx;
		width: 180upx;
		font-size: 24upx;
		color: #C7C7C7;
		text-align: center;
		line-height: 70upx;
	}
	.listmiddle {
		width: 700upx;
		height: 248upx; /* 318- 244  */
		box-sizing: border-box;
		padding: 24upx 10upx;
		display: flex;
	}
	.image {
		width: 200upx;
		height: 200upx;
		background-color: orangered;
		border-radius: 15upx;
	}
	.discripe {
		width: 480upx;
		height: 200upx;
		box-sizing: border-box;
		padding: 10upx 35upx;
	}
	.discripe .title {
		width: 100%;
		height: 60upx;
		font-size: 31upx;
		font-weight: 550;
		text-align: left;
		color: #111;
	}
	.discripe .standard {
		width: 100%;
		height: 60upx;
		font-size: 27upx;
		color: #929292;
		line-height: 60upx;
		text-align: left;
	}
	.discripe .price {
		width: 100%;
		height: 60upx;
		font-size: 30upx;
		line-height: 60upx;
		text-align: left;
		color: #f00;
		font-weight: 550;
	}
	.listbottom {
		width: 700upx;
		height: 70upx;
		border-top: 0.5upx solid #EEE;
		display:flex;
	}
	.status {
		width: 470upx;
		height: 60upx;
		font-size: 24upx;
		margin-top: 10upx;
		line-height: 60upx;
		box-sizing: border-box;
		padding-left: 15upx;
		color: #929292;
	}
	.btn {
		width: 150upx;
		height: 50upx;
		background-color: #C74F35;
		font-size: 24upx;
		line-height: 50upx;
		text-align: center;
		margin-left: 50upx;
		margin-top: 18upx;
		border-radius: 20upx;
		color: #fff;
	}
	/* 设定 */
	.tabcon {
		width: 3750upx;
		height: 100%;
		display: flex;
		flex-wrap: nowrap;
		position: absolute;
		left:0;
		top: 115upx;
		-webkit-transition: all .2s;
		transition: all .2s;
	}
</style>
