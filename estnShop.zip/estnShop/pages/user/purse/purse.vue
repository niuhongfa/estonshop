<template>
	<view class="body">
		<view class="maxtop">
			<view class="back iconfont icon-jiantou3" @click="toback"></view>
			<view class="purse">钱包</view>
			<view class="recharge" @click="showdel">充值</view>
		</view>
		<view class="card">
			<view class="topline">
				<image class="image" src=""></image>
				<view class="pursenum">艺术币:&nbsp&nbsp3000</view>
			</view>
			<view class="bottomline">
				<view class="pricetext">账户余额</view>
				<view class="money">￥1000</view>
			</view>
		</view>
		<view class="widthdraw">提现</view>
		<view class="btn">
			<view class="fenxiao">分销记录</view>
			<view class="record">我的充值记录</view>
			<view class="expense">我的支出</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			toback(){
				uni.navigateBack(1)
			},
		}
	}
</script>

<style>
	* {}
	.body {
		padding-top: 100upx;
	}
/* 头部导航 */
	.maxtop {
		width:750upx;
		height: 80upx;
		display: flex;
		margin-bottom: 20upx;
		background-color: #fff;
		position:fixed;
		top: 0;
		left: 0;
		right: 0;
	}
	.maxtop .back {
		width:80upx;
		height: 80upx;
		background-color: #fff;
		font-size: 34upx;
		line-height: 80upx;
		text-align: center;
		margin-right: 260upx;
	}
	.maxtop .purse {
		width:90upx;
		height: 80upx;
		text-align: center;
		box-sizing: border-box;
		padding-left: 20upx;
		font-size: 35upx;
		font-weight: 550;
		line-height: 80upx;
		margin-right: 240upx;
	}
	.recharge {
		width:80upx;
		height: 80upx;
		box-sizing: border-box;
		line-height: 80upx;
		font-size: 30upx;
	}
/* 钱包卡片*/
	.card {
		width: 660upx;
		height: 370upx;
		margin-left: 45upx;
		box-sizing: border-box;
		color: white;
		background: repeating-linear-gradient(#C53912 15%, #CD4621 30%);
		border-radius: 20upx;
	}

	.card .topline {
		width: 660upx;
		height: 200upx;
		display: flex;
		box-sizing: border-box;
		padding: 50upx 90upx;
		display: flex;
	}
	.image {
		width: 100upx;
		height: 100upx;
		background-color: pink;
		border-radius: 50%;
		margin: 0 40upx;
	}
	.pursenum {
		width: 300upx;
		height: 100upx;
		line-height: 120upx;
		font-size: 38upx;
	}

	.card .bottomline{
		width: 660upx;
		height: 170upx;
		display: flex;
		box-sizing: border-box;
		padding: 20upx 70upx;
	}
	.pricetext {
		width:200upx;
		height: 70upx;
		text-align: left;
		line-height: 70upx;
		font-size: 38upx;
	}
	.money {
		width:320upx;
		height: 70upx;
		text-align: right;
		line-height: 70upx;
		font-size: 38upx;
	}
/* 提现*/
	.widthdraw {
		width: 660upx;
		height: 80upx;
		background-color: #C53912;
		color: #fff;
		text-align: center;
		line-height: 80upx;
		font-size: 30upx;
		margin: 20upx 45upx;
		border-radius: 20upx;
	}
/* 其他 */
	.btn {
		width: 660upx;
		height: 80upx;
		display: flex;
		background-color: #FFF;
		color: #111;
		text-align: center;
		line-height: 70upx;
		font-size: 30upx;
		margin-left: 45upx;
		box-sizing: border-box;
		padding-top: 10upx;
		padding-left: 35upx;
	}
	.btn .fenxiao {
		width: 160upx;
		height: 70upx;
		border: 1upx solid #222;
		border-radius: 20upx;
		margin-right: 25upx;
	}
	.btn .record {
		width: 210upx;
		height: 70upx;
		border: 1upx solid #222;
		border-radius: 20upx;
		margin-right: 25upx;
	}
	.btn .expense {
		width: 160upx;
		height: 70upx;
		border: 1upx solid #222;
		border-radius: 20upx;

	}
</style>
