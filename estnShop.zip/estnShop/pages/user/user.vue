<!-- 个人中心 -->
<template>
    <view class="body">
        <!-- 已登录 -->
        <view class="" >
            <view class="personal">
                <view class="percont" @click="touserlist(1)">
                    <view>166****6677</view>
                    <view>进入我的首页&nbsp&nbsp&nbsp></view>
                </view >
                <image src="../../static/img/qq.png" class="img"></image>
            </view>
            <view class="purse">
                <view class="contentype" @click="touserlist(2)">
                    <view class="one">钱包</view>
                    <view class="two iconfont icon-cash"></view>
                </view>
                <view class="contentype" @click="touserlist(3)">
                    <view class="one">优惠券</view>
                    <view class="two iconfont icon-youhuiquan1"></view>
                </view>
            </view>
            <view class="car" >
                <view class="contentype" @click="touserlist(4)">
                    <view class="one">我买到的</view>
                    <view class="two iconfont icon-icon-test14"></view>
                </view>
                <view class="contentype" @click="touserlist(5)">
                    <view class="one">购物车</view>
                    <view class="two iconfont icon-cart"></view>
                </view>
                <view class="contentype" @click="touserlist(6)">
                    <view class="one">我的收藏</view>
                    <view class="two iconfont icon-wujiaoxing"></view>
                </view>
            </view>
            <view class="enterset">
                <view class="contentype" @click="touserlist(7)">
                    <view class="one">我的延伸用户</view>
                    <view class="two iconfont icon-yonghu"></view>
                </view>
                <view class="contentype" @click="touserlist(8)" v-show="!isenter">
                    <view class="one">艺术家入驻</view>
                    <view class="two iconfont icon-tubiaolunkuo-"></view>
                </view>
                <view class="contentype" @click="toented" v-show="isenter">
                    <view class="one">作品管理</view>
                    <view class="two iconfont icon-renzhengchenggong"></view>
                </view>
                <view class="contentype" @click="toented" v-show="!isenter">
                    <view class="one">艺术品管理</view>
                    <view class="two iconfont icon-xianxing_renzheng"></view>
                </view>
                <view class="contentype" @click="touserlist(9)">
                    <view class="one">设置</view>
                    <view class="two iconfont icon-setting"></view>
                </view>
            </view>
            
        </view>
        <!-- 未登录 -->
    </view>
</template>
<script>
    export default {
        computed: {
        },
        data(){
            return {
                hasLogin: "",
                isenter: ""
            }
        },
        methods: {
            bindLogin() {
                this.$store.commit("logindown");
                uni.reLaunch({
                    url: '../login/login'
                });
            },
            touserlist(id){
                if(id == 1){
                    uni.navigateTo({
                        url: 'myprofile/myprofile'
                    });
                }else if(id == 2){
                    uni.navigateTo({
                        url: 'purse/purse'
                    });
                }else if(id == 3){
                    uni.navigateTo({
                        url: 'youhuiquan/youhuiquan'
                    });
                }else if(id == 4){
                    uni.navigateTo({
                        url: 'mybought/mybought'
                    });
                }else if(id == 5){
                    uni.navigateTo({
                        url: 'car/car'
                    });
                }else if(id == 6){
                    uni.switchTab({
                        url: '../collection/collection'
                    });
                }else if(id == 7){
                    uni.navigateTo({
                        url: 'myusers/myusers'
                    });
                }else if(id == 8){
                    uni.navigateTo({
                        url: 'enter/enter'
                    });
                }else if(id == 9){
                    uni.navigateTo({
                        url: 'set/set'
                    });
                }
            },
            toented(){
                uni.navigateTo({
                    url: "ented/ented?id=2"
                })
            }
        },
        onReady() {
            //获取是否登陆的标识
            this.hasLogin = this.$store.state.hasLogin;
            this.isenter = this.$store.getters.getvip;             
        }

    }
</script>

<style>
    .body {
        width:750upx;
        height: auto;
        background-color:  #FFF;
    }
/* 分项 */
    .contentype {
        width: 100%;
        height: 90upx;
        border-bottom: 2upx solid #EEEEEE;
        position: relative;
    }
    .one {
        width: 200upx;
        height: 90upx;
        box-sizing: border-box;
        padding-left: 6upx;
        font-size: 30upx;
        line-height: 90upx;
        position: absolute;
        top: 0;
        left: 20upx;
    }
    .two {
        width: 60upx;
        height: 90upx;
        font-size: 45upx;
        text-align: center;
        line-height: 90upx;
        position: absolute;
        top: 0;
        right: 20upx;
    }
/*个人资料*/
    .personal {
        width: 100%;
        height:150upx;
        border-top: 15upx solid #EEEEEE;
        box-sizing: content-box;
        border-bottom: 15upx solid #EEEEEE;
        position: relative;
    }
    .personal>.percont {
        width: 300upx;
        height:100%;
        position: absolute;
        top: 0;
        left: 20upx;
    }
    .personal>.percont :first-child{
        width: 100%;
        height: 75upx;
        box-sizing: border-box;
        padding-top: 15upx;
        line-height: 75upx;
        font-size: 38upx;
        font-weight: 550;
    }
    .personal>.percont :last-child{
        width: 100%;
        height: 75upx;
        font-size: 30upx;
        color: #CACACA;
    }
    .personal>.img {
        width: 100upx;
        height: 100upx;
        position: absolute;
        top: 25upx;
        right: 25upx;
        background-color: pink;
    }
/* 钱包优惠券 */
    .purse {
        width: 100%;
        height:180upx;
        border-bottom: 15upx solid #EEEEEF;
        box-sizing: content-box;
    }
/* 购物车 */
    .car {
        width: 100%;
        height:270upx;
        box-sizing: content-box;
        border-bottom: 15upx solid #EEEEEE;
    }
/*用户开户*/
    .enterset {
        width: 100%;
        height:270upx;
        box-sizing: content-box;
        border-bottom: 15upx solid #EEEEEE;
    }
</style>
