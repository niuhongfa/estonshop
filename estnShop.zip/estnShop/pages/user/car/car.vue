<template>
	<view class="body"> 
		<view class="maxtop">
			<view class="back iconfont icon-jiantou3" @click="toback"></view>
			<view class="title">购物车</view>
			<view class="manage" v-show="!recall" @click="showdel">编辑</view>
			<view class="manage" v-show="recall" @click="recallshow">取消</view>
		</view>
		<view class="empty" v-if="!hasLogin">
			<image class="image" src="../../../static/images/emptyCart.jpg"></image>
			<view class="emptyl">
				<text >空空如也!</text>
				<navigator class="navigator"  url="/pages/login/login" v-if="!hasLogin">去登陆></navigator>
			</view>
		</view>
		<view class="empty" v-if="hasLogin && empty===true">
			<image class="image" src="../../../static/images/emptyCart.jpg"></image>
			<view class="emptyl">
				<text >空空如也!</text>
				<navigator class="navigator"  url="/pages/main/main" open-type="switchTab"  v-if="hasLogin">随便逛逛></navigator>
			</view>
		</view>
		<view class="contentcar" v-if="hasLogin && empty===false" v-for="(item,index) in cartList" :key="item.id" >
			<view class="seller"> <!-- 此处将要点击注册进入店铺 -->
				<view class="iconfont" :class="item.allselect === '1'?'radiol1 icon-duihao2':'radiol2 icon-yuancircle46'" @click="ischecked1(item.id)"></view>
				<view class="theseller">
					<image :src="item.image" class="img"></image>
					<view class="name">{{ item.puser }}</view>
				</view>
			</view>
			<view class="commodity"><!-- 此处将要点击注册进入商品页面 -->
				<view class=" iconfont" :class="item.block === '1'?'radiol3 icon-duihao2':'radiol4 icon-yuancircle46'" @click="ischecked2(item.id)" ></view>
				<image :src="item.image" class="images"></image>
				<view class="content2">
					<view class="conlist1">{{ item.title }}</view>
					<view class="conlist2">{{ item.discripe }}</view>
					<view class="conlist3">
						<view class="pic">￥{{ item.price }}</view>
						<view class="count">×{{ item.discount }}</view>
					</view>
				</view>
			</view>
			
			<view class="operate">
			<view class="buy" v-show="!delORbuy">
				<view class="iconfont" :class="allChecked?'radioll1 icon-duihao2':'radioll2 icon-yuancircle46'" @click="ischecked0" ></view>
				<view class="allsel" @click="ischecked0">全选</view>
				<view class="account">
					<view class="text">合计:</view>
					<input type="text" :value="accounts" disabled class="inputl" />
				</view>
				<view class="finish" @click="toaccount">结算</view>
			</view>
			<view class="delete" v-show="delORbuy">
				<view class="iconfont" :class="allChecked?'radioll1 icon-duihao2':'radioll2 icon-yuancircle46'" @click="ischecked0"></view>
				<view class="allsel" @click="ischecked0">全选</view>
				<view class="spacewhite"></view>
				<view class="finish" @click="hiddendel">删除</view>
			</view>
		</view>
		</view>
		
	</view>
</template>

<script>
import {
		mapState
	} from 'vuex';
import uniNumberBox from '@/components/uni-number-box.vue'
	export default {
		components:{uniNumberBox},
		data() {
			return {
				empty: false, //空白页现实  true|false
				total: 0, //总价格
				allChecked: false, //全选状态  true|false
				hasLogin: "",
				delORbuy: false,// false为全买 true 全删
				recall: false,//取消
			}
		},
		computed:{
			accounts(){
				let pricecount = 0;
				this.cartList.filter(item => {
					if( item.block ==="1"){
						let ll = parseInt(item.price);
						console.log(parseInt(item.price))
						pricecount += ll;
					}
				})
				this.total = pricecount;
				return pricecount
			},
		},
		watch:{
			empty(){
				return this.cartList;
			},
			total(){
				this.cartList.filter(item => {
					if(item.block === "0" || item.allselect === "0"){
						this.allChecked = false;
						return;
					}
				})
			}
		},
		methods: {
			toback(){
				uni.navigateBack(1)
			},
			showdel(){
				this.delORbuy = true;
				this.recall = true;
			},
			ischecked0(){
				this.allChecked = !this.allChecked;
				if(this.allChecked == true){
					this.cartList.filter(item => {
						item.block = "1"
						item.allselect = "1"
					})
				}
				if(this.allChecked == false){
					this.cartList.filter(item => {
						item.block = "0"
						item.allselect = "0"
					})
				}

				
			},
			recallshow(){
				this.delORbuy = false;
				this.radio = false;
				this.listChecked = false;
				this.allChecked = false;
				this.recall = false;
				this.cartList.filter(item => {
					item.block = "0";
					item.allselect = "0";
				})
			},
			ischecked1(id){
				this.cartList.find(item => {
					if(item.id === id){
						if(item.allselect == "0"){
							item.allselect = "1"
						}
						if(item.allselect == "1"){
							item.allselect = "0"
						}
					}
				})
				console.log(this.cartList)
			},
			ischecked2(id){
				this.cartList.filter(item => {
					if(item.id === id){
						if(item.block === "0"){
							item.block = "1"
						}
						if(item.block === "1"){
							item.block = "0"
						}
					}
				})
				console.log(this.cartList)
				// 有条件实行子元素全选父元素自动被选
			},
			hiddendel(){
				let count = [];
				this.cartList.filter(item => {
					if(item.block === "1"){
						count.push(parseInt(item.id)-1)
					}
				})
				
				console.log(count)
				
				console.log(this.cartList)
				this.delORbuy = false;
				this.radio = false;
				this.listChecked = false;
				this.allChecked = false;
				this.recall = false
			},
			toaccount(){
				 // 结算传出总数字 跳入结算页面付款审核
			}
		},
		onLoad: function(){
			this.hasLogin = this.$store.state.hasLogin;
			this.cartList = this.$store.state.carlist;
		},
		onShow(){
		}
	}
</script>

<style >
	*{
		padding:0;
		margin:0;
	}
	.body{
		background-color: #EEEEEE;
		padding-bottom: 90upx;
	}
/* 头部 */
	.maxtop {
		width:750upx;
		height: 80upx;
		display: flex;
		margin-bottom: 20upx;
		background-color: #fff;

	}
	.maxtop .back {
		width:80upx;
		height: 80upx;
		background-color: #fff;
		font-size: 34upx;
		line-height: 80upx;
		text-align: center;
	}
	.maxtop .title {
		width:650upx;
		height: 80upx;
		box-sizing: border-box;
		padding-left: 20upx;
		font-size: 35upx;
		font-weight: 550;
		line-height: 80upx;
	}
	.maxtop .manage {
		width:100upx;
		height: 80upx;
		box-sizing: border-box;
		line-height: 80upx;
		font-size: 30upx;
	}
/* 空白页 */
	.empty {
		position: fixed;
		top: 82upx;
		left: 0;
		right: 0;
		bottom:0;
		z-index: 9999;
		box-sizing: border-box;
		background-color: #fff;
	}
	.empty .image{
		width:350upx;
		height:280upx;
		margin: 300upx 200upx 0;
	}
	.empty .emptyl{
		 width: 300upx;
		 height:60upx;
		 display: flex;
		 margin-left:225upx;
	}
	.emptyl :first-child {
		width:140upx; 
		height:60upx;
		font-size: 30upx;
		line-height: 60upx;
		color: #C4C7CF;
	}
	.emptyl .navigator {
		width: 160upx;
		height: 60upx;
		line-height: 60upx;
		font-size: 30upx;
		color: #FA436A;
	}
/* 购物分项 */
	.contentcar {
		width: 750upx;
		min-height: 320upx;
		height: auto;
		border-bottom: 20upx solid #EEEEEE;
		border-radius: 30upx;
		background-color: #fff;
		padding-bottom: 10upx;
		overflow: hidden;
	}
	.contentcar {}
	.seller {
		width: 750upx;
		height: 75upx;
		display: flex;
		box-sizing: border-box;
		padding-top: 13upx;
	} /* 选中  */
	 .radiol1{
		width: 70upx;
		height: 60upx;
		line-height: 60upx;
		font-size: 36upx;
		text-align: center;
		/*color: #C74F35;*/
	}/* 未选中  */
	 .radiol2{ 
		width: 70upx;
		height: 60upx;
		line-height: 60upx;
		text-align: center;
		font-size: 42upx;
		font-weight: 1;
	}
	 .radiol3{
		width: 90upx;
		height: 190upx;
		font-size: 36upx;
		line-height: 190upx;
		text-align: center;
		padding-left: 20upx;
		/*color: #C74F35;*/
	}/* 未选中  */
	 .radiol4{ 
		width: 90upx;
		height: 190upx;
		line-height: 190upx;
		text-align: center;
		font-size: 42upx;
		font-weight: 1;
		padding-left: 20upx;
	}
	.seller .theseller{
		width: 680upx;
		height: 60upx;
		display: flex;
	}
	.seller .theseller .img{
		width: 60upx;
		height: 60upx;
		border-radius: 50%;
		background-color: orangered;
	}
	.seller .theseller .name{
		width: 580upx;
		height: 60upx;
		box-sizing: border-box;
		padding-left: 20upx;
		font-size: 30upx;
		line-height: 60upx; 
	}
    .commodity  {
        width: 750upx;
        height: 210upx;
        display: flex;
        box-sizing: border-box;
        padding-top: 20upx;
        border-top: 1upx solid #EEE;
    }
    
    .commodity .radio{
		width: 90upx;
		height: 190upx;
		background-color: #0ff;
    }
    .commodity .images{
        width: 200upx;
        height: 190upx;
        border-radius: 10upx;
        background-color: pink;
    }
    .commodity .content2 {
        width: 420upx;
        height: 190upx;
        box-sizing: border-box;
        position: relative;
        padding: 15upx 0 7.5upx 50upx;
    }
    .commodity  .content2 .conlist1 {
        width:420upx;
        height: 60upx;
        font-size: 29upx;
        box-sizing: border-box;
        padding-top: 25upx;
    }
    .commodity  .content2 .conlist2 {
        width:420upx;
        height: 60upx;
        font-size: 23upx;
        color: #8C8C8C;
        line-height: 70upx;
    }
    .commodity  .content2 .conlist3 {
        width:420upx;
        height: 60upx;
        display:flex;
    }
    .commodity  .content2 .conlist3 :nth-of-type(1){
		width: 350upx;
		height: 60upx;
		font-size: 27upx;
		color: #F00;		 
    }
    .commodity  .content2 .conlist3 :nth-of-type(2){
		width: 70upx;
		height: 60upx;
		font-size: 27upx;
		color: #222; 
    }
/* 全操作 */
	.operate{
		position:fixed;
		left: 0;
		right: 0;
		bottom: 0;
		top: 1247upx;
		box-sizing: border-box;
		border-top: 2upx solid #ccc;
		background-color: #fff;
	} 
	.radioll1 {
		width: 76upx;
		height: 54upx;
		line-height: 54upx;
		font-size: 36upx;
		text-align: center;
		color: #111;
		margin-left:10upx;
	}
	.radioll2 {
		width: 76upx;
		height: 54upx;
		line-height: 54upx;
		text-align: center;
		font-size: 44upx;
		font-weight: 1;
		margin-left:10upx;
	}
	.allsel {
		width: 78upx;
		height: 54upx;
		line-height: 54upx;
		font-size: 26upx;
		color: #111;
	}
	.spacewhite {
		width: 440upx;
		height: 54upx;
	}
	.account {
		width: 440upx;
		height: 54upx;
		display:flex;
	}
	.account .text {
		width: 80upx;
		height: 54upx;
		line-height: 54upx;
		text-align: left;
		font-size: 26upx;
		color: #111;
	}
	.inputl {
		width: 340upx;
		height: 54upx;
		line-height: 54upx;
		font-size: 26upx;
		color: #f00;
	}
	.finish {
		width: 110upx;
		height: 54upx;
		box-sizing: border-box;
		line-height: 54upx;
		text-align: center;
		background-color: #C63C17;
		font-size: 28upx;
		border-radius: 27upx;
		color: #fff;
	}
/* 全买 */
	.buy {
        width: 750upx;
        height: 84upx;
		display: flex;
		box-sizing: border-box;
		padding-top: 15upx;
	}
/* 全删 */
    .delete {
        width: 750upx;
        height: 84upx;
		display: flex;
		box-sizing: border-box;
		padding-top: 15upx;
    }
</style>
