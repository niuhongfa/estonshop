<template>
	<view>
		<view class="userList" v-for="item in listusers" :key="item.id">
        	<view class="userAvatar">
        		<img :src="item.url">
        	</view>
        	<view class="userContent">
        		<view class="userName">{{ item.name }}</view>
        		<view class="userTime">{{ item.ctime | getTime }}</view>
        	</view>
        </view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				listusers: [
		            {"id":1,"aid":"1","name":"用户1","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":2,"aid":"2","name":"作品1","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":3,"aid":"1","name":"用户2","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":4,"aid":"3","name":"文章2","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":5,"aid":"1","name":"用户3","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":6,"aid":"3","name":"文章3","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":7,"aid":"1","name":"用户5","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":8,"aid":"2","name":"作品3","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":9,"aid":"2","name":"作品5","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":10,"aid":"1","name":"用户7","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":11,"aid":"3","name":"文章10","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":12,"aid":"2","name":"作品31","url":"../../../static/images/qrcode.png","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":13,"aid":"1","name":"用户22","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":14,"aid":"3","name":"文章22","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":15,"aid":"1","name":"用户13","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":16,"aid":"3","name":"文章113","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":17,"aid":"1","name":"用户15","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":18,"aid":"2","name":"作品13","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":19,"aid":"2","name":"作品15","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":20,"aid":"1","name":"用户17","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		            {"id":21,"aid":"3","name":"文章110","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
		        ],
			}
		},
		methods: {
			
		},
		filters:{
			getTime(time){
				var date = new Date(time);
				return date.getFullYear() + "-" + date.getMonth()+1+ "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
			}
		}
	}
</script>

<style>
	.userList {
		width: 750upx;
		height: 88upx;
		margin: 0;
		box-sizing: border-box;
		padding-left: 40upx;
		border-bottom: 1upx solid #E8E8E8;
		display: flex;
	}
	.userAvatar {
		width: 88upx;
		height: 88upx;
	}
	.userAvatar	img {
		width: 70upx;
		height: 70upx;
		margin: 8upx 8upx;
	}
	.userContent{
		width: 600upx;
		height: 88upx;
		}
	.userName {
		width: 600upx;
		height: 36upx;
		margin-top: 6upx;
		font-size: 30upx;
		line-height: 36upx;
	}
	.userTime {
		width: 600upx;
		height: 36upx;
		margin-top: 4upx;
		line-height: 36upx;
		font-size: 30upx;
	}
</style>
