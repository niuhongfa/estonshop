<template>
	<view>
		<view>
			<button  type="default" @tap="bindLogin" v-if="hasLogin">退出登录</button>
			<button  type="default" @tap="bindLogin" v-if="!hasLogin">登录</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				hasLogin: ""
			}
		},
		methods: {
			bindLogin() {
                this.$store.commit("logindown");
                uni.reLaunch({
                    url: '../../login/login'
                });
            },
		},
		onLoad: function(e){
			this.hasLogin = this.$store.state.hasLogin
		}
	}
</script>

<style>
	button {
		width: 750upx;
		height: 70upx;
		line-height: 70upx;
		background-color: orangered;
	}
</style>
