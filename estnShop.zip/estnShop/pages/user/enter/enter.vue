<template>
	<view>
		<view class="body">
			<view class="one">
				<image class="image" src=""></image>
				<view class="uname">粉蓝色</view>
			</view>
			<view class="two">
				<view class="clist">
					<view class="iconfont icon-yuanquan"></view>
					<view class="btitle">适用艺术家</view>
				</view>
				<view class="clist">
					<view class="ktitle">适用于所有销售需求的艺术家</view>
				</view>
			</view>
			<view class="three">
				<view class="clist">
					<view class="iconfont icon-yuanquan"></view>
					<view class="btitle">身份特权</view>
				</view>
				<view class="clist">
					<view class="iconfont icon-triangle-right"></view>
					<view class="ititle">发表作品功能</view>
					<view class="iconfont icon-duihao2"></view>
				</view>
			</view>
			<view class="four">
				<view class="clist">
					<view class="iconfont icon-triangle-right"></view>
					<view class="ititle">独立运营后台</view>
					<view class="iconfont icon-duihao2"></view>
				</view>
				<view class="clist">
					<view class="iconfont icon-triangle-right"></view>
					<view class="ititle">发表文章功能</view>
					<view class="iconfont icon-duihao2"></view>
				</view>
			</view>
			<view class="five">
				<view class="clist">
					<view class="iconfont icon-triangle-right"></view>
					<view class="ititle">我的统计功能</view>
					<view class="iconfont icon-duihao2"></view>
				</view>
				<view class="clist">
					<view class="iconfont icon-triangle-right"></view>
					<view class="ititle">入围推荐页</view>
					<view class="iconfont icon-duihao2"></view>
				</view>
				<view class="clist">
					<view class="iconfont icon-triangle-right"></view>
					<view class="ititle">广告投放特权</view>
					<view class="iconfont icon-duihao2"></view>
				</view>
			</view>
			<view class="six">
				<view class="iconfont icon-triangle-right"></view>
				<view class="ititle">销售作品权限</view>
				<view class="iconfont icon-duihao2"></view>
			</view>
			<view class="seven">
				<view class="xie">
					<text class="xieyitip">点击申请入驻，代表您已同意</text>
					<text class="xieyi" @click="toxieyi">《一统天下入驻条款》</text>
				</view>
				<view class="btn" @click="tonext">
					申请入驻
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			toxieyi(){
				uni.navigateTo({
					url: "xieyi/xieyi"
				})
			},
			tonext(){
				uni.navigateTo({
					url: "selfmsg/selfmsg"
				})
			}
		}
	}
</script>

<style>
	.body{
		width: 750upx;
		height: auto;
	}
	.clist {
		width: 680upx;
		display: flex;
	}
	.icon-duihao2 {
		width: 35upx;
		height: 60upx;
		line-height: 60upx;
		font-size: 26upx;
	}
	.icon-yuanquan {
		width: 40upx;
		height: 60upx;
		line-height: 60upx;
		font-size: 36upx;
	}
	.icon-triangle-right {
		width:35upx;
		height: 60upx;
		line-height: 60upx;
	}
	.btitle {
		width:300upx;
		height: 60upx;
		line-height: 60upx;
		font-size: 24upx;
	}
	.ititle {
		width: 615upx;
		height: 60upx;
		font-size: 24upx;
		line-height: 60upx;
		color: #898989;
	}
	.ktitle {
		font-size: 24upx;
		color: #898989;
		padding-left: 30upx;
	}
	.one{
		width: 750upx;
		height: 300upx;
		box-sizing: border-box;
		border-bottom: 1upx solid #EEE;
		background-color: #C74F2E;
	}
	.image{
		width: 90upx;
		height: 90upx;
		border-radius: 50%; 
		background-color: lightpink;
		margin-top: 90upx;
		margin-left: 330upx;
	}
	.uname {
		width:200upx;
		height: 36upx;
		font-size: 28upx;
		margin-left: 275upx;
		text-align: center;
		color: #fff;
	}
	.two{
		width: 750upx;
		height: 120upx;
		box-sizing: border-box;
		border-bottom: 1upx solid #EEE;
		padding-left: 35upx;
		
	}
	.three{
		width: 750upx;
		height: 120upx;
		box-sizing: border-box;
		border-bottom: 1upx solid #EEE;
		padding-left: 35upx;
		
	}
	.four{
		width: 750upx;
		height: 120upx;
		box-sizing: border-box;
		border-bottom: 1upx solid #EEE;
		padding-left: 35upx;
		
	}
	.five{
		width: 750upx;
		height: 190upx;
		box-sizing: border-box;
		border-bottom: 1upx solid #EEE;
		padding-left: 35upx;
	}
	.six{
		width: 750upx;
		height: 70upx;
		box-sizing: border-box;
		border-bottom: 1upx solid #EEE;
		padding-left: 35upx;
		display: flex;
	}
	.seven{
		width: 750upx;
		height: 230upx;
		border-top: 20upx solid #EEE;
		border-bottom: 1upx solid #EEE;
	}
	.xie {
		width: 570upx;
		height:110upx;
		margin: 0 90upx;
		box-sizing: border-box;
		
	}
	.xieyitip {
		width: 285upx;
		height: 30upx;
		font-size: 24upx;
		color: #898989;
	}
	.xieyi {
		width: 285upx;
		height: 30upx;
		font-size: 24upx;
		color: #64C2FA;
	}
	.btn {
		width: 650upx;
		height: 80upx;
		border-radius: 20upx;
		margin: 0 50upx;
		text-align: center;
		line-height: 80upx;
		font-size: 30upx;
		color: #FFF;
		background-color: #C74F2E;
	}
</style>
