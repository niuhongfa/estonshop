<template>
	<view>
		<h4>艺术家入驻条款</h4>
		<view class="content">
			<p>她真傻</p>
		</view>
		<view class="agree">我同意</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
		}
	}
</script>

<style>
*{
	margin: 0;
		padding: 0;
}
	h4{
		width: 750upx;
		height: 100upx;
		text-align: center;
	}
	.content {
		width: 650upx;
		margin: 0 auto;
		height: auto;
		background-color: #0ff;
		font-size: 24upx;
	}
	p{
		width: 100%;
		height: 40upx;
		line-height: 40upx;
		text-indent: 2em;
	}
	.agree{
		width: 500upx;
		height: 60upx;
		font-size: 30upx;
		color: #FFF;
		text-align: center;
		line-height: 60upx;
		border-radius: 20upx;
		margin-left: 125upx;
		background-color: #f00;
	}
</style>
