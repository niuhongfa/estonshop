<template>
	<view>
		<view class="tips">
			<view >个人信息</view>
			<view>———</view>
			<view class="rred">证件照片</view>
			<view>———</view>
			<view >其他信息</view>
		</view>
		<view class="btn" @click="tonext">
			下一步
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			tonext(){
				uni.navigateTo({
					url: "/pages/user/enter/other/other"
				})
			}
		}
	}
</script>

<style>
	.tips {
		width: 690upx;
		box-sizing: border-box;
		padding: 30upx 20upx;
		height: 100upx;
		font-size: 34upx;
		display:flex;
		margin-left: 40upx;
	}
	.rred{
		color: red;
	}
	.btn {
		width: 450upx;
		height: 80upx;
		box-sizing: border-box;
		background-color: #C53A14;
		margin: 40upx 150upx;
		border-radius: 20upx;
		text-align:center;
		line-height: 80upx;
		font-size: 30upx;
		color: #FFF;
	}
</style>
