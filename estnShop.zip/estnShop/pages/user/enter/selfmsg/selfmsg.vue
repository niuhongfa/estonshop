<template>
	<view class="body">
		<view class="content">
			<view class="tips">
				<view class="rred">个人信息</view>
				<view>———</view>
				<view >证件照片</view>
				<view>———</view>
				<view >其他信息</view>
			</view>
			<view class="one">
				<view class="title">*您的姓名</view>
				<input class="input" type="text" required v-model="name"/>
			</view>
			<view class="one">
				<view class="title">*绑定手机</view>
				<input class="input" type="text" required v-model="phone"/>
			</view>
			<view class="one">
				<view class="title">*所在地区</view>
				<input class="input" @tap="toggleTab" type="text" required disabled v-model="resultInfo.result" ref="picker"/>
			</view>
			<view class="one">
				<view class="title">*身份证号</view>
				<input class="input" type="text" required v-model="idnum"/>
			</view>
			<view class="btn" @click="tonext">
				下一步
			</view>

		</view>
		<w-picker 
			mode="region"
			step="5"  
			@confirm="onConfirm" 
			ref="picker" 
			themeColor="#f00"
		></w-picker>
	</view>
</template>

<script>
	import wPicker from "@/components/w-picker/w-picker.vue";
	export default {
		components:{
			wPicker
		},
		data() {
			return {
				tabList:[
				{
					mode:"region",
					name:"省市区",
					value:[10,0,5]
				}],
				resultInfo:{},
				name:"",
				phone:"",
				idnum:""
			}
		},
		computed:{
		},
		onLoad() {

		},
		watch:{
			resultInfo(){
				console.log(this.resultInfo.result)
			}
		},
		methods: {
			toggleTab(){
				this.$refs.picker.show();
			},
			onConfirm(val){
				this.resultInfo=val;
			},
			tonext(){
				let bat = /^([\w\u4E00])+$/;
				let reh = /^1[35678]\d{9}$/;
				let sh  = /[1234567890]{18}/
				if(this.name === ""){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '姓名不能为空'
                    });
                    return;
				}
				if(bat.test(this.name)){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '姓名输入非法'
                    });
                    return;
				}
				if(this.phone === ""){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '手机号不能为空'
                    });
                    return;
				}
				if(!(/^1[35678]\d{9}$/.test(this.phone))){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '手机号格式有误'
                    });
                    return;
				}
				if(this.resultInfo.result === undefined){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '所在地区不能为空'
                    });
                    return;
				}
				if(this.idnum === ""){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '身份证号不能为空'
                    });
                    return;
				}
				if(!(sh.test(this.idnum))){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '身份证号输入不正确'
                    });
                    return;
				}
				uni.navigateTo({
					url: "/pages/user/enter/picmsg/picmsg"
				})
			}
		},
		onShow(e){
		}
	}
</script>

<style>
	* {
		padding: 0;
		margin: 0;
	}
	.body {
		width: 750upx;
		box-sizing: border-box;
		margin-top: -20upx;
	}
	.content{
		width: 750upx;
		height: auto;
		border-top: 40upx solid #EEE;
		background-color: #fff;
		box-sizing: border-box;
	}
	.tips {
		width: 690upx;
		box-sizing: border-box;
		padding: 30upx 30upx;
		height: 100upx;
		font-size: 34upx;
		display:flex;
		margin: 0 auto;
	}
	.rred{
		color: red;
	}
	.one {
		width:670upx;
		height: 100upx;
		margin-left: 20upx;
		display: flex;
		box-sizing: border-box;
		padding-top: 10upx;
		box-sizing: border-box;
	}
	.title {
		width:140upx;
		height: 100upx;
		font-size: 30upx;
		margin-right: 20upx;
		line-height: 85upx;
		text-align: center;
	}
	.input {
		width: 510upx;
		height: 80upx;
		margin-bottom: 10upx;
		box-sizing: border-box;
		padding-left: 10upx;
		border: 0.5upx solid #333;
		font-size: 30upx;
	}
	.btn {
		width: 450upx;
		height: 80upx;
		box-sizing: border-box;
		background-color: #C53A14;
		margin: 40upx 150upx;
		border-radius: 20upx;
		text-align:center;
		line-height: 80upx;
		font-size: 30upx;
	}
</style>
