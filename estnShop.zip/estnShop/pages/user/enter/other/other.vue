<template>
	<view>
		<view class="tips">
			<view >个人信息</view>
			<view>———</view>
			<view >证件照片</view>
			<view>———</view>
			<view class="rred">其他信息</view>
		</view>
		<view class="one">
				<view class="title">*您的头衔</view>
				<input class="input" type="text" required placeholder="无/县级/市级/省级/国家级" />
			</view>
			<view class="one">
				<view class="title">您的老师</view>
				<input class="input" type="text" required placeholder="齐白石" />
			</view>
			<view class="one">
				<view class="title">老师头衔</view>
				<input class="input" type="text" required placeholder="无/县级/市级/省级/国家级" />
			</view>
		<view class="btn" @click="tonext">
			下一步
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			tonext(){
				uni.navigateTo({
					url: "/pages/user/enter/submit/submit"
				})
			}
		}
	}
</script>

<style>
	.tips {
		width: 690upx;
		box-sizing: border-box;
		padding: 30upx 20upx;
		height: 100upx;
		font-size: 34upx;
		display:flex;
		margin-left: 40upx;
	}
	.rred{
		color: red;
	}
	.one {
		width:670upx;
		height: 100upx;
		margin-left: 35upx;
		display: flex;
		box-sizing: border-box;
		padding-top: 10upx;
		box-sizing: border-box;
	}
	.title {
		width:140upx;
		height: 100upx;
		font-size: 30upx;
		margin-right: 20upx;
		line-height: 75upx;
		text-align: center;
	}
	.input {
		width: 510upx;
		height: 70upx;
		margin-bottom: 20upx;
		line-height: 70upx;
		box-sizing: border-box;
		padding-left: 10upx;
		border: 0.5upx solid #333;
		font-size: 30upx;
	}
	.btn {
		width: 450upx;
		height: 80upx;
		box-sizing: border-box;
		background-color: #C53A14;
		margin: 40upx 150upx;
		border-radius: 20upx;
		text-align:center;
		line-height: 80upx;
		font-size: 30upx;
		color: #FFF;
	}
</style>
