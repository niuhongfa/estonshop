<template>
	<view>
		<view class="topx iconfont icon-renzhengchenggong"></view>
		<view class="middle">
			<view class="text">您的信息已提交成功，我们将尽快审核并与您联系，请保持手机通畅</view>
		</view>
		<view class="btn" @click="tonext">回到个人中心</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isvip:"",
			}
		},
		methods: {
	        getvip(){
	            uni.getStorage({
	                key:"isvip",
	                success(e){
	                    this.isvip = e.data.vip
	                    console.log(this.isvip)
	                }
	            })
	        },
			tonext(){
				uni.setStorage({
			        key:"isvip",
			        data:{
			        	vip:1
			        }
		        }); 
				this.getvip();
				uni.switchTab({
					url: "/pages/user/user"
				})
			},
		},
		watch:{
			getvip(){
				console.log(this.isvip)
			}
		},
		onLoad(e){
		}
	}
	/**
	 * 存:
        uni.setStorage({
        key:"属性名”，
        data:"值”
        })
        /---------------------------
        取
        uni.getStorage({
        key:"属性名”,
        success(e){
        e.data//这就是你想要取的token
        }
        })
	 */
</script>

<style>
	.topx{
		width: 750upx;
		height: 140upx;
		font-size: 100upx;
		text-align: center;
		line-height: 140upx;
		border-top: 20upx solid #EEE;
	}
	.middle{
		width: 750upx;
		height: 350upx;
		box-sizing: border-box;
		padding: 110upx 105upx;
		color: #fff;
		font-size: 34upx;
		background-color: #C53A14;
	}
	.btn {
		width: 650upx;
		height: 80upx;
		box-sizing: border-box;
		background-color: #C53A14;
		margin: 40upx 50upx;
		border-radius: 20upx;
		text-align:center;
		line-height: 80upx;
		font-size: 30upx;
		color: #FFF;
	}
</style>
