<template>
	<view class="body">
		<view class="addaddress" >
			<view class="ttop">
				<view class="back iconfont icon-fanhui" @click="goback"></view>
				<view class="title">管理收货地址</view>
				<view class="manage" @click="iconfirm">保存</view>
			</view>
			<view class="inputmsg">
			    <input type="text" placeholder="收货人" class="input" v-model="uname" required/>
			    <view class="tother iconfont icon-home_content_sponsor"></view>
			</view>
			<view class="inputmsg">
				<input type="text" placeholder="手机号码" class="input" v-model="uphone" required/>
				<view class="tother iconfont icon-shouji1"></view>
			</view>
			<view class="inputmsg" @click="openPicker">
				<input type="resert" placeholder="所在地区" class="input" disabled v-model:value="region"/>
				<view class="tother iconfont icon-jiantouyou"></view>
			</view>
			<view class="inputmore">
				<textarea placeholder="详细收货地址:如街道,小区,楼栋号,单元室" class="imore" v-model="uaddress" required></textarea>
			</view>
			<view class="defaultmsg">
				<view class="defaultm">设为默认地址</view>
	            <switch  @change="switch1Change" class="toother" :checked="ccecked?true:false"/><!--选中 checked -->
			</view>
			<button  class="addbtn" @click="senddel" >删除这个收货地址</button>
			<lotus-address v-on:choseVal="choseValue" :lotusAddressData="lotusAddressData" class="addcontent" ></lotus-address>

		</view>
	</view>
</template>

<script>
import lotusAddress from "@/components/lotusAddress/Winglau14-lotusAddress.vue"
	export default {
		components:{
			lotusAddress
		},
		data() {
			return {
				addresslist:[
					
				],
				uname: "",
				uphone: "",
	            region:'',
				uaddress: "",
				ccecked: "",
				lotusAddressData:{
                visible:false,
                provinceName:'',
                cityName:'',
                townName:'',
                ischecked: ''
	            },
			}
		},
		methods: {
			goback() {
				uni.navigateBack(1)
			},
			getmsg(){
				this.addresslist.find(item => {
					if(this.$route.query.id == item.id){
						this.uphone = item.phonenum;
						this.uname = item.uname;
						this.region = item.uaddress;
						this.uaddress = item.waddress;
						this.ccecked = item.checked;
					}
				})
			},
			setdefault(id){
				this.addresslist.filter(item => {
					if(item.id !== id){
						item.checked = false;
					}
					if(item.id === id){
						item.checked = true;
					}
				})
			},
            openPicker() {
	            this.lotusAddressData.visible = true;
	        },
	        //回传已选的省市区的值
	        choseValue(res){
	            this.lotusAddressData.visible = res.visible;//visible为显示与关闭组件标识true显示false隐藏
	            //res.isChose = 1省市区已选 res.isChose = 0;未选
	            if(res.isChose){
	                this.lotusAddressData.provinceName = res.provice;//省
	                this.lotusAddressData.cityName = res.city;//市
	                this.lotusAddressData.townName = res.town;//区
	                this.region = `${res.provice} ${res.city} ${res.town}`; //region为已选的省市区的值
	                console.log( this.region)
	            }
	        },
	        switch1Change: function (e) {
	        	this.ischecked = e.detail.value
	        },
			iconfirm() {
                let reh = /^1[35678]\d{9}$/;
				if(this.uname ===''){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '收件人不能为空'
                    });
                    return;
				}else if(this.uphone ===''){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '手机号码不能为空'
                    });
                    return;
				}else if(reh.test(this.uphone) === false){
                    uni.showToast({  //弹窗
                        icon: 'none',
                        title: '您的手机号格式不正确'
                    });
                    return;
                }else if(this.region ===''){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '所在地区请选择'
                    });
                    return;
				}else if(this.uaddress ===''){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '详细收货地址不能为空'
                    });
                    return;
				}else if(this.uaddress.length<5){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '详细收货地址不能少于五个字符'
                    });
                    return;
				}else{
					if(this.ischecked == true){
						this.addresslist.filter(item =>{
							item.checked = false
						})
					}
					var addressmsg = {
						"id":`${this.$route.query.id}`,
						"uname":`${this.uname}`,
						"phonenum":`${this.uphone}`,
						"uaddress":`${this.region}`,
						"waddress":`${this.uaddress}`,
						"checked":this.ischecked
					};
					this.$store.commit("setyouraddress",addressmsg);
					
					uni.redirectTo({
		                url: '/pages/user/myprofile/address/address'
		            })
				}
			},
			senddel(){
				this.$store.commit("deladdress",this.$route.query.id)
				uni.redirectTo({
	                url: '/pages/user/myprofile/address/address'
	            })
			}
		},
		onLoad: function(e){
			this.addresslist = this.$store.state.youraddress;
			this.getmsg();
			console.log(this.$store.state.youraddress);
		}
	}
</script>

<style>
	.body{
		width: 750upx;
		height: auto;
		background-color: #EFEFEF;
	}
/* 管理 */
	
	/* 修改地址 */
    .addaddress {
    	position: fixed;
    	left: 0;
    	top: 0;
    	bottom: 0;
    	right: 0;
    	z-index: 999;
    }
    .ttop {
		width:750upx;
		height:90upx;
		box-sizing: border-box;
		padding-top: 15upx;
		display: flex;
		border-bottom: 2upx solid #EAEAEA;
	}
	.ttop .back {
		width:60upx;
		height: 60upx;
		text-align: center;
		line-height: 60upx;
		font-weight: 700;
		margin-right: 225upx;
		font-size: 46upx;
	}
	.ttop .title{
		width:200upx;
		height: 60upx;
		font-size: 32upx;
		font-weight: 700;
		margin-right: 210upx;
		text-align: center;
		line-height: 60upx;
	}
	.ttop .manage {
		width:100upx;
		height: 60upx;
		line-height: 60upx;
		color: #F00;
		font-size: 32upx;
	}
	.inputmsg {
		width: 100%;
        height:90upx;
        border-top: 2upx solid #EEEEEE;
        box-sizing: border-box;
        padding-top: 25upx;
        position: relative;
        background-color: #FFF;
    	color: #111;
    }
    .inputmsg:first-child {
        padding-top: 0upx;
    	height: 90upx;
    	margin-bottom: 20upx;
    	background-color: #fff;
    	font-size: 40upx;
    	font-weight: 500;
    	text-align: center;
    	line-height: 90upx;
        color: #000; 
    }
    .inputmsg .input {
    	width: 630upx;
    	height: 60upx;
        box-sizing: border-box;
        padding-top: 15upx;
    	font-size: 30upx;
    	position: absolute;
    	left: 20upx;
    	top: 0;

    }
    .inputmsg .tother {
    	width:60upx;
    	height:60upx;
    	font-size: 40upx;
    	box-sizing: border-box;
    	padding-top: 15upx;
    	line-height: 60upx;
    	position: absolute;
    	top: 0;
    	right: 15upx;
    }
    .defaultmsg {
    	width: 750upx;
    	height: 90upx;
    	position: relative;
    	background-color: #fff;
    	left: 0upx;
    	top: 0;
    }
    .defaultmsg .defaultm {
    	width: 600upx;
		height: 90upx;
    	font-size: 30upx;
    	line-height: 90upx;
    	position: relative;
    	background-color: #fff;
    	left: 10upx;
    	top: 0;
    }
    .defaultmsg .toother {
    	width:110upx;
    	height:60upx;
    	box-sizing: border-box;
    	padding-top: 15upx;
    	position: absolute;
    	top: 0;
    	right: 10upx;
    }
	.inputmore {
		width: 100%;
        height:180upx;
        border-top: 2upx solid #EEEEEE;
        box-sizing: border-box;
        border-bottom: 2upx solid #EEEEEE;
        background-color: #fff;
        padding-top: 20upx;
        padding-left: 10upx;
	}  
	.inputmore .imore {
		width: 100%;
		height: 140upx;
		font-size: 30upx;
	}  
    .addbtn {
    	width: 100%;
    	height: 90upx;
    	background-color: #FFF;
    	color: #f00;
        padding-left: 10upx;
    	margin-top: 150upx;
    }
   /*  .delete {
   	width: 750upx;
   	height: 90upx;
   	box-sizing: border-box;
   	position: relative;
   	background-color: #fff;
   	left: 0upx;
   	top: 0;
   }
   .del {
   	width:280upx;
   	height:75upx;
   	line-height: 75upx;
   	color: #FF0000;
   	border: none;
   	background-color: #fff;
   	margin: 20upx 10upx 0 0;
   	border-radius: 10upx;
   	position: absolute;
   	top: 0;
   	right: 10upx;
   } */
</style>
