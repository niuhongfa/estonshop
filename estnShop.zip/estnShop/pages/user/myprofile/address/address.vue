<template>
	<view class="body">
		<view class="ttop">
			<view class="back iconfont icon-fanhui" @click="goback"></view>
			<view class="title">收货地址</view>
		</view>
		<view class="addaddress" v-show="addshow">
			<view class="maxtop">
			    <view class="back iconfont icon-jiantou3" @click="rel"></view><view class="text">添加收货地址</view>
			</view>
			<view class="inputmsg">
			    <input type="text" placeholder="收货人" class="input" v-model="uname" required/>
			    <view class="tother iconfont icon-home_content_sponsor"></view>
			</view>
			<view class="inputmsg">
				<input type="text" placeholder="手机号码" class="input" v-model="uphone" required/>
				<view class="tother iconfont icon-shouji1"></view>
			</view>
			<view class="inputmsg" @click="openPicker">
				<input type="resert" placeholder="所在地区" class="input" disabled v-model:value="region"/>
				<view class="tother"></view>
			</view>
			<view class="inputmore">
				<textarea placeholder="详细收货地址:如街道,小区,楼栋号,单元室" class="imore" v-model="uaddress" required></textarea>
			</view>
			<view class="defaultmsg">
				<view class="defaultm">设为默认地址</view>
	            <switch  @change="switch1Change" class="toother" /><!--选中 checked -->
			</view>
			<button  class="addbtn" @click="iconfirm">保存</button>
			<lotus-address v-on:choseVal="choseValue" :lotusAddressData="lotusAddressData" class="addcontent" ></lotus-address>

		</view>
			
		<view class="address" v-for="item in addresslist" :key="item.id" @click="toManage(item.id)">
			<view :class="item.checked?'radio iconfont icon-duihao2':'noradio iconfont icon-yuanquan'" @click="setdefault(item.id)"></view><!-- tubiao -->
			<view class="content">
				<view class="userphone">
					<view class="user"><view class="icoo  iconfont icon-home_content_sponsor"></view><view>{{item.uname}}</view>
					</view>
					<view class="phone"><view class="icoo iconfont icon-shouji1"></view><view>{{item.phonenum}}</view>
					</view>
					<view class="seted" @click="toManage(item.id)">编辑</view>
				</view>
				<view class="useraddress">收货地址:&nbsp
				&nbsp{{item.uaddress+item.waddress}}</view>
			</view><!-- neirong -->
		</view>
		<button @click="addaddress">添加收货地址</button>
	</view>
</template>

<script>
 import lotusAddress from "@/components/lotusAddress/Winglau14-lotusAddress.vue"
	export default {
		components:{
			lotusAddress
		},
		data() {
			return {
				addresslist:[
					
				],
				addshow: false,
				uname: "",
				uphone: "",
	            region:'',
				uaddress: "",
				lotusAddressData:{
                visible:false,
                provinceName:'',
                cityName:'',
                townName:'',
                ischecked: ''
	            },
			}
		},
		methods: {
			addaddress(){
				this.addshow = true;
			},
			rel(){
				this.addshow = false;
			},
			setdefault(id){
				this.addresslist.filter(item => {
					if(item.id !== id){
						item.checked = false;
					}
					if(item.id === id){
						item.checked = true;
					}
				})
			},
            openPicker() {
	            this.lotusAddressData.visible = true;
	        },
	        //回传已选的省市区的值
	        choseValue(res){
	            this.lotusAddressData.visible = res.visible;//visible为显示与关闭组件标识true显示false隐藏
	            //res.isChose = 1省市区已选 res.isChose = 0;未选
	            if(res.isChose){
	                this.lotusAddressData.provinceName = res.provice;//省
	                this.lotusAddressData.cityName = res.city;//市
	                this.lotusAddressData.townName = res.town;//区
	                this.region = `${res.provice} ${res.city} ${res.town}`; //region为已选的省市区的值
	                console.log( this.region)
	            }
	        },
	        switch1Change: function (e) {
	        	this.ischecked = e.detail.value
	        },
			iconfirm() {
                let reh = /^1[35678]\d{9}$/;
				if(this.uname ===''){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '收件人不能为空'
                    });
                    return;
				}else if(this.uphone ===''){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '手机号码不能为空'
                    });
                    return;
				}else if(reh.test(this.uphone) === false){
                    uni.showToast({  //弹窗
                        icon: 'none',
                        title: '您的手机号格式不正确'
                    });
                    return;
                }else if(this.region ===''){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '所在地区请选择'
                    });
                    return;
				}else if(this.uaddress ===''){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '详细收货地址不能为空'
                    });
                    return;
				}else if(this.uaddress.length<5){
					uni.showToast({  //弹窗
                        icon: 'none',
                        title: '详细收货地址不能少于五个字符'
                    });
                    return;
				}else{
					if(this.ischecked == true){
						this.addresslist.filter(item =>{
							item.checked = false
						})
					}
					var addressmsg = {
						"id":`${this.addresslist.length+1}`,
						"uname":`${this.uname}`,
						"phonenum":`${this.uphone}`,
						"uaddress":`${this.region}`,
						"waddress":`${this.uaddress}`,
						"checked":this.ischecked
					};
					this.$store.commit("changeyouraddress",addressmsg);
					
					uni.redirectTo({
		                url: '/pages/user/myprofile/address/address'
		            })
				}
			},
			goback() {
				uni.navigateBack(1)
			},
			toManage(id){
				uni.navigateTo({
	                url: '/pages/user/myprofile/address/manage/manage?id='+id
	            })
			}
		},
		watch: {
		},
		onLoad: function(e){
			this.addresslist = this.$store.state.youraddress;
			console.log("我一刷新")
		},
		onshow: function(e){
		}
	}
</script>

<style>
	*{
		margin: 0;
		padding: 0;
	}
    .body {
    	width: 750upx;
    	min-height:200upx;
    	background-color: #F8F8F8;
    }
    .maxtop {
		width: 750upx;
		height: 90upx;
		display: flex;
		background-color: #fff;
		margin-bottom: 20upx;
	}
	.back{ 
	width: 60upx;
	height:90upx;
	font-size: 46upx;
	line-height: 90upx;
	text-align: center;
	margin-right: 200upx;
	font-weight: 700upx;}
	.maxtop .text{
		width: 230upx;
		height: 90upx;
		line-height: 90upx;
		text-align: center;
	}
/* 管理 */
	.ttop {
		width:750upx;
		height:90upx;
		box-sizing: border-box;
		padding-top: 15upx;
		display: flex;
	}
	.ttop .back {
		width:60upx;
		height: 60upx;
		text-align: center;
		line-height: 60upx;
		font-weight: 700;
		margin-right: 240upx;
	}
	.ttop .title{
		width:150upx;
		height: 60upx;
		font-size: 32upx;
		font-weight: 700;
		margin-right: 210upx;
		text-align: center;
		line-height: 60upx;
	}
/* 添加地址 */
    .addaddress {
    	position: fixed;
    	left: 0;
    	top: 0;
    	bottom: 0;
    	right: 0;
    	z-index: 999;
    	background-color: #EAEAEA;
    }
    .addcontent{
    	top: 380upx;
    	width:750upx;
    	height:700upx;
    }
	.inputmsg {
		width: 100%;
        height:90upx;
        border-top: 2upx solid #EEEEEE;
        box-sizing: border-box;
        padding-top: 15upx;
        position: relative;
        background-color: #FFF;
    	color: #959595;
    }
    .inputmsg:first-child {
        padding-top: 0upx;
    	height: 90upx;
    	margin-bottom: 20upx;
    	background-color: #fff;
    	font-size: 40upx;
    	font-weight: 500;
    	text-align: center;
    	line-height: 90upx;
        color: #000; 
    }
    .inputmsg .input {
    	width: 630upx;
    	height: 60upx;
    	font-size: 30upx;
    	position: absolute;
    	left: 20upx;
    	top: 0;

    }
    .inputmsg .tother {
    	width:60upx;
    	height:60upx;
    	font-size: 45upx;
    	box-sizing: border-box;
    	padding-top: 15upx;
    	position: absolute;
    	top: 0;
    	right: 15upx;
    }
    .defaultmsg {
    	width: 750upx;
    	height: 90upx;
    	position: relative;
    	background-color: #fff;
    	left: 0upx;
    	top: 0;
    }
    .defaultmsg .defaultm {
    	width: 600upx;
		height: 90upx;
    	font-size: 30upx;
    	line-height: 90upx;
    	position: relative;
    	background-color: #fff;
    	left: 10upx;
    	top: 0;
    }
    .defaultmsg .toother {
    	width:110upx;
    	height:60upx;
    	box-sizing: border-box;
    	padding-top: 15upx;
    	position: absolute;
    	top: 0;
    	right: 10upx;
    }
	.inputmore {
		width: 100%;
        height:180upx;
        border-top: 2upx solid #EEEEEE;
        box-sizing: border-box;
        border-bottom: 2upx solid #EEEEEE;
        background-color: #fff;
        padding-top: 20upx;
        padding-left: 10upx;
	}  
	.inputmore .imore {
		width: 100%;
		height: 140upx;
		font-size: 30upx;
	}  
    .addbtn {
    	width: 100%;
    	height: 90upx;
    	background-color: red;
        padding-left: 10upx;
    	margin-top: 150upx;
    }
/* 我的已有地址 */
	.address {
		width: 750upx;
		height: 160upx;
		display: flex;
		margin-top: 10upx;
		background-color: #fff;
	}
	.address .radio{
		width: 60upx;
		height: 160upx;
		box-sizing: border-box;
		padding-left: 10upx;
		font-size: 30upx; 
		line-height: 160upx
	}
	.address .noradio{
		width: 60upx;
		height: 160upx;
		box-sizing: border-box;
		padding-left: 10upx;
		font-size: 40upx; 
		line-height: 160upx
	}
	.address .content{
		width: 690upx;
		height:160upx;
		background-color: #fff;
	}
	.address .content .userphone {
		width: 690upx;
		height: 80upx;
		line-height: 80upx;
		display: flex;
	}
	.address .content .userphone>.user {
		min-width: 250upx;
		height: 80upx;
		box-sizing: border-box;
		margin-right: 20upx;
		display: flex;
	}
	.address .content .userphone>.user :last-child {
		min-width: 170upx;
		height: 100%;
		font-size: 28upx;

	}
	.icoo {
		width: 70upx;
		height: 80upx;
		font-size: 55upx;
		margin: 0upx;
	}
	.address .content .userphone>.phone {
		width: 430upx;
		height: 80upx;
		font-size: 30upx;
		box-sizing: border-box;
		display: flex;
	}
	.address .content .userphone>.phone :last-child {
		min-width: 170upx;
		height: 100%;
		font-size: 28upx;

	}
	.address .content .seted {
		 width: 100upx;
		 height: 80upx;
		 font-size: 30upx;
	}
	.address .content .useraddress {
		width: 100%;
		height: 80upx;
		font-size: 28upx;
		line-height: 80upx;
		color: #959595;
	}
</style>
