<template>
	<view>
		<button class="address" @click="toaddress">收货地址</button>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			toaddress(){
				uni.navigateTo({
                    url: 'address/address'
                });
			}
		}
	}
</script>

<style>
	.address {
		width: 400upx;
		height: 70upx;
		background-color: pink;
	}
</style>
