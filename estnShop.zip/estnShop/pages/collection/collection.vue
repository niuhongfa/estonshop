<template>
	<view class="body">
        <view class="collect">
    		<view class="collectlist" v-for="item in collectList" :key="item.id" >
                <view class="content1">
                    <image class="image" :src="item.url"></image>
                </view>
                <view class="content2">
                    <view class="conlist1">{{ item.title }}</view>
                    <view class="conlist2">{{ item.discripe }}</view>
                    <view :class="item.book=='0'?'conlist3':'conlist33'">{{ item.book==0?item.price:'已被预订' }}</view>
                    <view class="btn" @click="showl(item.id)">取消收藏</view>
                </view>
            </view>
        </view>
        <view class="show"  v-show="showd">
        <view class='delcontent' :class="showd==true?'transformy':''">
            <view class=" de1">确定不喜欢了吗</view>
            <view @click="del" class="de2">不喜欢了</view>
            <view @click="hiddenl" class="de3">取消</view>
        </view>
        </view>
	</view>
</template>

<script>
export default {
    data () {
        return {
            collectList: [],
            isbug: '',
            showstyle: '',
            showd: '',
            delid: ''
        }
    },
    components: {
    },
    methods: {
        showl(id){
            this.showd = true;
            this.delid = id;
        },
        del(){
            this.$store.commit("delcollect",this.delid);
            this.showd = false;
        },
        hiddenl(){
            this.showd = false;
        }
    },
    onLoad: function(e){
        this.collectList = this.$store.state.collectshop;
    }
}
/**
 * transformX(){
            let currentTab = this.currentTab;
            return `translate3d(${currentTab*100}%, 0px, 0px)`
        },
        transformXx(){
            let currentTab = this.currentTab;
            return `translate3d(-${currentTab*100}%, 0px, 0px)`
        }


            display: block;
            white-space: nowrap;
            -webkit-transition: all .3s;
            transition: all .3s;
            width: 100%;
            overflow: visible;
            will-change: transform,left,top;
 */
</script>
<style>
    * {
        margin: 0;
        padding: 0;
    }
    .body {
        width: 750upx;
        height: auto;
        background-color: #fff;
    }
    .collect {
        width: 750upx;
        height: auto;
        border-top: 16upx solid #EEE;

    }
    .collect .collectlist {
        width: 750upx;
        height: 280upx;
        margin: 0 auto;
        display: flex;
        box-sizing: border-box;
        padding: 15upx;
        border-bottom: 2upx solid #EEEEEE;
    }
    .collect .collectlist .content1 {
        width: 250upx;
        height: 250upx;
        box-sizing: border-box;
        padding: 7.5upx;
    }
    .collect .collectlist .content1 .image {
        width: 235upx;
        height: 235upx;
        border-radius: 10upx;
    }
    .collect .collectlist .content2 {
        width: 470upx;
        height: 250upx;
        box-sizing: border-box;
        position: relative;
        padding: 15upx 0 7.5upx 30upx;
    }
    .collect .collectlist .content2 .conlist1 {
        width:420upx;
        height: 70upx;
        font-size: 29upx;
        margin-top: 15upx;
        box-sizing: border-box;
        padding-top: 25upx;
    }
    .collect .collectlist .content2 .conlist2 {
        width:420upx;
        height: 70upx;
        font-size: 23upx;
        color: #CACACA;
        line-height: 70upx;
    }
    .collect .collectlist .content2 .conlist3 {
        width:420upx;
        height: 70upx;
        font-size: 27upx;
        color: #FF0000;
    }
    .collect .collectlist .content2 .conlist33 {
        width:420upx;
        height: 70upx;
        font-size: 27upx;
    }
    .collect .collectlist .content2 .btn {
        width:120upx;
        height: 40upx;
        text-align: center;
        line-height: 40upx;
        position: absolute;
        right: 15upx;
        bottom: 15upx;
        font-size: 20upx;
        font-weight: 200;
        color: #FFF;
        border-radius: 8upx;
        background-color: #190E6A;
    }
    .show {
        position:fixed;
        top:0;
        left: 0;
        right: 0;
        bottom: 0;
        width:100%;
        height:100%;
        z-index: 9999;
    }
    .delcontent { 
        -webkit-transition: all 1s;
        transition: all 1s;
        overflow: visible;
        will-change: transform,top;
        width: 100%;
        height: 300upx;
        background-color: #FFF;
        position: absolute;
        bottom: 300upx;
        left: 0;
    }
    .de1 {
        width: 100%;
        height: 90upx;
        text-align: center;
        line-height: 90upx;
        color: #111;
        font-size: 28upx;
    }
    .de2 {
        width: 100%;
        height: 90upx;
        text-align: center;
        line-height: 90upx;
        color: #F00;
        font-size: 32upx;
        border-bottom: 2upx solid #EEE;
    }
    .de3 {
        width: 100%;
        height: 90upx;
        text-align: center;
        line-height: 90upx;
        font-size: 30upx;
        border-top: 20upx solid #EEEEEE;

    }
    .transformy {
        transform: translateY(300upx);
    }
</style>
