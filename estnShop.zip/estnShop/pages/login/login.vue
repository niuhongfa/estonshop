<!-- 登录 -->
<template>
    <view class="body">
        <view class="mainarea">
           <view class="discripe">登录</view>

           <view class="user"> 
                <text class="iicol iconfont icon-shouji"></text>
                <input type="text" placeholder="请输入账号或手机号" name="username" maxlength="11" class="iicot" v-model="username">
            </view>

            <view class="pass">
                <text class="iicol iconfont icon-xiugaimima"></text>
                <input type="password" placeholder="请输入密码" name="password" class="iict" maxlength="18" v-model="password">
                <text class="iicz iconfont icon-biyan"></text>
            </view>
            
            <button type="primary" class="login" @tap="bindLogin">登录</button> 
            <view @click="nologin" class="nologon"> 跳过登陆</view>
        </view>
        <navigator class="register" url="../reg/reg">
            还没注册？&nbsp去注册
        </navigator>
        <navigator class="forget" url="../pwd/pwd">忘记密码</navigator>
    </view>
     <!--   
     -->
</template>

<script>
    import service from '../../service.js';

    export default {
        components: {
        },
        data() {
            return {
                hasProvider: false,
                username: '',
                storagephone: '',
                storageuser: '',
                password: '',
                storagepass: '',
                positionTop: 0,
            }
        },
        computed: {},
        watch:{
            getdata(){
            }
        },
        methods: {
            initPosition() {
                /**
                 * 使用 absolute 定位，并且设置 bottom 值进行定位。软键盘弹出时，底部会因为窗口变化而被顶上来。
                 * 反向使用 top 进行定位，可以避免此问题。
                 */
                this.positionTop = uni.getSystemInfoSync().windowHeight - 100;
            },
            bindLogin() {
                let rec = /[a-z|A-Z]/;
                let res = /\s/;
                let reh = /^1[35678]\d{9}$/;
        /*输入不合法*/
                if(this.username === '' || this.password === '') {
                    uni.showToast({  //功能正常
                        icon: 'none',
                        title: '账号密码不能为空'
                    });
                    return;
                }else if(this.username.length < 8) {
                    uni.showToast({  //功能正常
                        icon: 'none',
                        title: '账号最短为 8 个字符'
                    });
                    return;
                }else if(this.password.length < 6){
                    uni.showToast({  // 功能正常
                        icon: 'none',
                        title: '密码最短为 6 个字符'
                    });
                    return;
                }else if(rec.test(this.password) === false){
                    uni.showToast({  // 功能正常
                        icon: 'none',
                        title: '密码必须包含一个英文字符'
                    });
                    return;
                }else if(res.test(this.password)){
                    uni.showToast({  // 功能正常
                        icon: 'none',
                        title: '密码不能包含空格'
                    });
                    return;
                } else {


                    ////////////////////////////
                    this.$store.commit("getKey",this.username);
                    this.$store.commit("getuserpass");
                    let sphone = this.$store.state.phone;
                    let suser = this.$store.state.user; //暂时没有制作账号的功能 此时为undefind
                    let spass = this.$store.state.pass;
                    if(this.username === suser || this.username === sphone && this.password === spass){
                            uni.reLaunch({  //跳转
                                url: '../main/main',
                            });
                            this.$store.commit("login",this.username);
                        
                    }
                    if(this.username !== suser && reh.test(this.username) === false){
                        uni.showToast({  //弹窗
                            icon: 'none',
                            title: '您的手机号格式不正确'
                        });
                        return;
                    }
                    if(this.username !== suser && this.username !== sphone && reh.test(this.username) === true){
                        uni.showToast({  //弹窗
                            icon: 'none',
                            title: '该手机号尚未注册'
                        });
                        return;
                    }
                    
                    
                }  
            },
            nologin(){
                uni.reLaunch({
                    url: '/pages/main/main'
                 })
                this.$store.commit("logindown");
                console.log(this.$store.state.hasLogin)
            },
            gets(){
                uni.getStorageInfo({  //获取所有key
                    success: function (res) {
                        console.log(res.keys);
                        console.log(typeof(res.keys))
                        console.log(res.currentSize);
                        console.log(res.limitSize);
                    },
                    fail:function(err){
                        console.log(err)
                    }
                })
            }
        },
        onReady() {
            this.initPosition();
       }
    }
    /*  */
    /**
     *
     * getllll(){
                uni.getStorageInfo({  //获取所有key
                    success: function (res) {
                        console.log(res.keys);
                        console.log(res.currentSize);
                        console.log(res.limitSize);
                    },
                    fail:function(err){
                        console.log(err)
                    }
                });
                uni.getStorage({
                    key: "lll",
                    success: function (res) {
                    },
                    fail:function(err){  //返回错误
                        console.log("不存在")
                    }
                });
            }
     *
     * 
     * 存:
        uni.setStorage({
        key:“属性名”，
        data:“值”
        })
        /---------------------------
        取
        uni.getStorage({
        key:“属性名”,
        success(e){
        e.data//这就是你想要取的token
        }
        })
     *
     * 
     * uni.setStorage({
                                key: 'searchLocal',
                                data: that.searchKey
                            });
     * 
     * uni.showToast({  //弹窗
                        icon: 'none',
                        title: '密码最短为 6 个字符'
                    });
                    return;
     *
     * uni.reLaunch({  //跳转
                        url: '../main/main',
                    });
     * 
     * initProvider() { //第三方授权
                const filters = ['weixin', 'sinaweibo'];
                uni.getProvider({
                    service: 'oauth',
                    success: (res) => {
                        if (res.provider && res.provider.length) {
                            for (let i = 0; i < res.provider.length; i++) {
                                if (~filters.indexOf(res.provider[i])) {
                                    this.providerList.push({
                                        value: res.provider[i],
                                        image: '../../static/img/' + res.provider[i] + '.png'
                                    });
                                }
                            }
                            this.hasProvider = true;
                        }
                    },
                    fail: (err) => {
                        console.error('获取服务供应商失败：' + JSON.stringify(err));
                    }
                });
            },
     */
</script>

<style>
    .body {
        width: 750upx;
        height: 1246upx;
        box-sizing: border-box;
        padding: 280upx 65upx 0;
        background-color: orangered;
    }
    .body>.mainarea {
        width: 620upx;
        height: 620upx;
        box-sizing: border-box;
        background-color: #fff;
        border-radius: 25upx;
        padding-top: 40upx;
    }
    .body>.register {
        width: 250upx;
        height: 50upx;
        font-size: 28upx;
        color: white; 
        text-align: center;
        margin: 70upx 0 0 185upx;
    }
    .body>.forget {
        width: 120upx;
        height: 50upx;
        font-size: 28upx;
        color: white;
        text-align: center;
        margin: 72upx 0 0 490upx;
    }
    .login {
        width: 440upx;
        height:64upx;
        margin-top: 80upx;
        background-color: #C63F1A;
        line-height: 64upx;
    }
    .discripe {
        width: 90upx;
        height: 50upx;
        font-size: 40upx;
        font-weight: 700;
        margin: 0 auto;
    }
    .user {
        width:480upx;
        height:120upx;
        display:flex;
        margin: 40upx auto 0;
        border-bottom: 2upx solid #ccc;
    }
    .iicol {
        width: 60upx;
        height: 60upx;
        margin: auto 10upx;
        margin-left: 0;
        font-size: 60upx;
    }
    .user>.iicot {
        width: 390upx;
        height: 60upx;
        margin: auto 0;
        background-color: #fff;
        box-sizing: border-box;
        padding-left: 10upx;
    }
    .pass {
        width:480upx;
        height:120upx;
        margin: 0 auto;
        display:flex;
        border-bottom: 2upx solid #ccc;
    }
    .pass>.iict {
        width: 340upx;
        height: 60upx;
        margin: auto 0;
        background-color: #fff;
        margin-right: 10upx;
        box-sizing: border-box;
        padding-left: 10upx;
    }
    .pass>.iicz {
         width: 60upx;
        height: 60upx;
        margin-top: 40upx;
        font-size: 40upx; 
    }
    input {
        background-color: #fff;
    }
    .nologon {
        height: 50upx;
        width: 140upx;
        font-size:32upx;
        margin: 50upx 20upx;
        color: #2975E6;
        font-weight: 550upx;
        background-color: #fff;
    }
</style>
