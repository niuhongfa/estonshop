<template>
	
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		onShow(){
			console.log(this.list)
		},
	}
</script>

<style >

</style>
