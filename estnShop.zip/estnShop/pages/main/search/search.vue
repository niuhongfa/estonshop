<template>
	<view >
		
			<view class="searchbox">	
				<view class="searchl">
		            <text class="icon1 iconfont icon-sousuo6" @click="searchNow"></text>
		            <input type="search" placeholder="搜作品/找艺术家" class="search" @confirm="searchNow($event)" v-model="ipt" @click="yesClick" onfocue>
		            <text class="icon2 iconfont icon-richscan_icon" @click="toScanQR"></text>
		        </view>
		        <view class="icon3"  @click="pageBack">取消</view>
			</view>
			<view class="searchList">
			<!-- 全部 -->
			<Tabs :TabList="TabList" :currentTab="current" @tabs="tabsChange">
		        <TabPane class="tabarea">
		             <view class="userList" v-for="item in listResult" :key="item.id">
		            	<view class="userAvatar">
		            		<img :src="item.url">
		            	</view>
		            	<view class="userContent">
		            		<view class="userName">{{ item.name }}</view>
		            		<view class="userTime">{{ item.ctime | getTime }}</view>
		            	</view>
		            </view>

		        </TabPane>
		        <!-- 用户 -->
		        <TabPane class="tabarea">
		            <view class="userList" v-for="item in listResultUser" :key="item.id">
		            	<view class="userAvatar">
		            		<img :src="item.url">
		            	</view>
		            	<view class="userContent">
		            		<view class="userName">{{ item.name }}</view>
		            		<view class="userTime">{{ item.ctime | getTime }}</view>
		            	</view>
		            </view>
		        </TabPane>
		        <!-- 作品 -->
		        <TabPane class="tabarea">
			        <view class="userListWorks" >
		                <view class="userImage" v-for="item in listResultWorks" :key="item.id" @click="toWorks(item.id)">
			            		<img :src="item.url">
				            	<view class="text">
				            		<view>小鸡吃米图</view>
				            		<view>李宏隆</view>
				            		<view>¥8888</view>
				            	</view>
			            </view>
		            </view>

		        </TabPane>
		        <!-- 文章 -->
		        <TabPane class="tabarea">
		             <view class="userListArticle" v-for="item in listResultArticle" :key="item.id" @click="toArticle(item.id)">
		            	<view class="userContent">
		            		<view>我我我</view>
		            		<view>哎,ta那么自恋,爱吃爱睡爱打游戏</view>
		            		<view>李宏隆</view>
		            	</view>
		            	<view class="userImage">
		            		<img :src="item.url">
		            		<navigator :url="'/pages/main/article/article?id='+item.id" open-type="navigate" class="text">
			            		<text>全文</text>
			            		<text class="iconfont icon-jiantou"></text>
		            		</navigator>
		            	</view>
		            </view>

		        </TabPane>
		    </Tabs>
			</view>
        <!-- 搜索历史 -->
		<view class="searchBotBox" v-show="flag">
			<view class="searchHistoryBox">
				<view class="searchHistoryBoxItem" v-for="(item,index) in searchKey" :key='index' ref="myLi" @click="liShiSearch(item)"  :data-id="index" :id="index">
					{{item}}
				</view>
			</view>
			<view class="ov">
				<view @tap="clearKey" class="fr grace-more-r grace-search-remove">清除历史记录</view>
			</view>
		</view>
	</view>
</template>
<script>
import Tabs from '@/components/search-tabs/tabs.vue'
import TabPane from '@/components/search-tabs/tabPane.vue'
import search from "@/components/jm-search/jm-search.vue"
	export default {
		components: {
	        Tabs,
	        TabPane
		},
		data() {
			return {
				current:0,
	            TabList:[
	                {title:'全部'},
	                {title:'用户'},
	                {title:'作品'},
	                {title:'文章'}
	            ],
				searchKey: [],
				ipt: '',
				searchClose: true,
				flag: true,
				list: [],
				listResult: [],
				listResultUser: [],
				listResultWorks: [],
				listResultArticle: []
			}
		},
		onLoad: function(e){
			this.list = this.$store.state.listSearch;
			console.log(this.list)
		},
		onShow: function(e){
			var vv = uni.getStorageSync('searchLocal');
			var arr = vv.split("-");
			this.searchKey = arr;
		},
		methods: {
	        tabsChange(index){
	            this.current = index;
	            this.flag = false;
	        },
			//清除搜索历史
			clearKey: function() {
				var that = this;
				uni.showModal({
					title: '提示',
					content: '点击确定将删除所有历史信息，确定删除吗？',
					success: function(res) {
						if (res.confirm) {
							that.searchKey = [];
							uni.setStorage({
								key: 'searchLocal',
								data: that.searchKey
							});
							
						} else if (res.cancel) {

						}
					}
				});
			},
			//跳转扫码页
	        toScanQR(){
                uni.navigateTo({
                    url: '/pages/main/ScanQR/ScanQR'
                });
            },
	        toWorks(id) {
	            uni.navigateTo({
	                url: '/pages/main/works/works?id='+id
	            });
	        },
	        toArticle(id){
	        	uni.navigateTo({
	                url: '/pages/main/article/article?id='+id
	            });
	        },
            //点击搜索框开始搜索 对后台拿来数据初次遍历
			searchNow: function(e) {
				if (this.ipt == '') {
					uni.showToast({
						title: '未输入搜索关键字',
						icon: 'none',
						duration: 1000
					});
					return false;
				}else{
					this.flag = false;
				}
				var that = this;
				var newArr = that.searchKey; //接收关键字
				newArr.push(this.ipt);       //添加到ipt
				this.searchKey = newArr;     //ipt 渲染到关键字 
				var newStr = newArr.join('-'); //
				uni.setStorage({
					key: 'searchLocal',
					data: newStr
				});
				this.list.find(item => {
					if (item.name.includes(this.ipt)){
						this.listResult.push(item);
					}
				});
				this.listResult.find(item => {
					if(parseInt(item.aid) === 1){
						this.listResultUser.push(item);
					}
					if(parseInt(item.aid) === 2){
						this.listResultWorks.push(item);
					}
					if(parseInt(item.aid) === 3){
						this.listResultArticle.push(item);

					}
				});
			},
			// 返回主页面
			pageBack() {
				uni.switchTab({
				    url: '/pages/main/main'
				});
			},
			// 点击搜索 清空预存本地list 并显示历史记录
			yesClick(){
				this.listResult = [];
				this.listResultArticle = [];
				this.listResultUser = [];
				this.listResultWorks = []; 
				this.flag = true;
			},
			otherHidden() {
				this.flag = false;
			},
			liShiSearch(value) {
				this.ipt = value;
				this.searchNow();
			}
		},
		filters:{
			getTime(time){
				var date = new Date(time);
				return date.getFullYear() + "-" + date.getMonth()+1+ "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds();
			}
		}
	}
</script>
<style lang="scss" scoped>
	*{
		margin:0;
	}
		.body {
			width:100%;
			height:1344upx;
			top: 0upx;
			background-color: #FFF;

		}
/* 搜索结果 全部和用户 */
	.tabarea{
		background-color: #fff;
	}
	.userList {
		width: 750upx;
		height: 88upx;
		margin: 0;
		padding: 0;
		border-bottom: 4upx solid #E8E8E8;
		display: flex;
		.userAvatar {
			width: 88upx;
			height: 88upx;
			img {
				width: 70upx;
				height: 70upx;
				margin: 8upx 8upx;
			}
		}
		.userContent{
			width: 600upx;
			height: 88upx;
			.userName {
				width: 600upx;
				height: 36upx;
				margin-top: 6upx;
				font-size: 30upx;
				line-height: 36upx;
			}
			.userTime {
				width: 600upx;
				height: 36upx;
				margin-top: 4upx;
				line-height: 36upx;
			}
		}
	}
/* //搜索结果 作品 */
.userListWorks {
	width: 730upx;
	margin: 10upx 0 0 20upx;
	padding: 0;
    column-count: 2;
    column-gap: 0upx;
    column-rule: 0upx;
	.userImage {
		width: 345upx;
		height: auto;
		margin: 0upx 0upx 4upx 0;
		break-inside: avoid; 
		img {
			width:100%;
		}
		.text {
			width: 100%;
			height: 130upx;
			box-sizing: border-box;
			margin: 0;
			padding: 0;
			:nth-of-type(1) {
				width: 100%;
				height: 33upx;
				font-size:30upx;
				font-weight: 500;
				margin-bottom: 10upx;
			    box-sizing: border-box;
			}
			:nth-of-type(2) {
				width: 100%;
				height: 33upx;
				font-size:26upx;
				color: rgba(0,0,0,.7);
				margin-bottom: 10upx;
			    box-sizing: border-box;
			}
			:nth-of-type(3) {
				width: 100%;
				height: 33upx;
				color: red;
				font-size:30upx;
				margin-bottom: 10upx;
			}
		}
		
	}
}
/* // 搜索结果 文章 */
.userListArticle {
	width: 750upx;
	height: 290upx;
	box-sizing: border-box;
	padding: 10upx 10upx;
	border-bottom: 4upx solid #E8E8E8;
	display: flex;
	.userContent {
		width: 500upx;
		height: 264upx;
		box-sizing: border-box;
		:nth-of-type(1) {
			width: 500upx;
			height: 50upx;
			font-size: 36upx;
			font-weight: 700;
			padding-left: 10upx;
			box-sizing: border-box;
		}
		:nth-of-type(2) {
			padding-top: 20upx;
			width: 500upx;
			height: 170upx;
			font-size: 30upx;
			box-sizing: border-box;
		}
		:nth-of-type(3) {
			width: 500upx;
			height: 50upx;
			line-height: 50upx;
			font-size: 30upx;
			box-sizing: border-box;
		}
	}
	.userImage {
		width: 250upx;
		height: 260upx;
		box-sizing: border-box;
		img {
			width:215upx;
			height: 160upx;
			margin: 50upx 10upx 0;
		}
		.text {
			width: 90upx;
			height: 50upx;
			font-size: 18upx;
			line-height: 50upx;
			margin: 0 0 0 135upx;
			:nth-of-type(1){
				width: 60upx; 
				font-size: 28upx;
			}
			:nth-of-type(2){
				width: 30;
				font-size: 28upx;
			}
		}
	}
}

/* // 搜索框 */
	.searchbox {
		width:750upx;
		height: 76upx;
	    display:flex;
	    margin-top: 10upx;
	    margin-bottom: 10upx;
	    padding-bottom: 10upx;
		position:fixed;
		z-Index:999;
		background-color: #fff;
		top:0;
		left:0;
	    .icon3 {
	    	width:80upx;
	    	height: 66upx;
	    	padding-left: 10upx;
	        line-height: 66upx;
	        font-size: 30upx;
	        border: none;
	    }
		.searchl {
		    width: 630upx;
		    height: 66upx;
		    margin-left: 30upx;
		    background-color: #CDCDCD;
		    display: flex;
		    justify-content: space-between;
			border-radius: 8upx;
		    .icon1 {
		        width: 50upx;
		        height: 66upx;
		        line-height: 66upx;
		        padding-left: 20upx;
		        font-size: 36upx;
		    }
		    .search {
		        width: 478upx;
		        height: 66upx;
		        font-size: 30upx;
		    }
		    .icon2 {
		        width: 50upx;
		        height: 66upx;
		        line-height: 66upx;
		        font-size: 36upx;
		    }
		 }   
	}

/* //搜索记录 */
	.ov {
		overflow: hidden;
		width: 230upx;
		margin: 0 auto;
		font-size: 30upx;
	}

	.fl {
		float: left;
	}

	.fr {
		float: right;
	}

	.searchBotBox {
		width: 100%;
		padding: 15upx 3%;
		box-sizing: border-box;
		bottom: 0;
		right:0;
		left: 0;
		position:absolute;
		top:150upx
	}

	.searchHistoryBox {
		width: 100%;
		box-sizing: border-box;
		overflow: hidden;
		margin-top: 40upx;
	}

	.searchHistoryBoxItem {
		float: left;
		font-size: 26upx;
		color: #666;
		line-height: 46upx;
		height: 46upx;
		padding: 0 20upx;
		border-radius: 23upx;
		margin-left: 15upx;
		margin-bottom: 20upx;
		border: 1px solid #ccc;
	}
	
</style>
