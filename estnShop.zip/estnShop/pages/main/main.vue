<template class="body">
    <view>
<!-- 搜索栏 -->
    <view class="searchl">
        <text class="icon1 iconfont icon-sousuo6"></text>
        <input type="search" placeholder="搜作品/找艺术家" class="search" @click="searchNavigato" disabled="">
        <text class="icon2 iconfont icon-richscan_icon" @click="toScanQR"></text>
    </view>
<!-- list -->
    <view class="mylist" ref="body">
        <wuc-tab :tab-list="tabList4" :tabCur.sync="TabCur4" tab-class="text-center text-white " select-class="text-white"></wuc-tab>
        <swiper :current="TabCur4" class="swiper row" duration="300" :circular="true" indicator-color="rgba(255,255,255,0)" indicator-active-color="rgba(255,255,255,0)" @change="swiperChange4">
    <!-- 首页 -->
            <swiper-item class="listContent"> 
            <!-- 轮播图 -->
                  <swiper class="screen-swiper square-dot" :indicator-dots="true" :circular="true"
         :autoplay="true" interval="3000" duration="500">
                        <swiper-item v-for="(item,index) in swiperList" :key="index">
                            <image :src="item.url" mode="aspectFill" v-if="item.type=='image'"></image>
                        </swiper-item>
                    </swiper>
            <!-- 榜单 -->
                <!-- 图片 用 background -->
                <view class="listOfName">
                    <view class="list" @click="toBangdan(1)">
                        <img class="tu" src="../../static/images/changxiao.jpg">
                        <view class="zi">畅销榜  </view>
                    </view>
                    <view class="list" @click="toBangdan(2)">
                        <img class="tu" src="../../static/images/dianzan.jpg">
                        <view class="zi">点赞榜  </view>
                    </view>
                    <view class="list" @click="toBangdan(3)">
                        <img class="tu" src="../../static/images/yishu.jpg">
                        <view class="zi">艺术榜  </view>
                    </view>
                    <view class="list" @click="toBangdan(4)">
                        <img class="tu" src="../../static/images/tuijian.jpg">
                        <view class="zi">推荐专题</view>
                    </view>
                    <view class="list" @click="searchNavigato">
                        <img class="tu" src="../../static/images/sousuo.jpg">
                        <view class="zi">搜索    </view>
                    </view>
                </view>
            <!-- 我们的活动 -->
                <view class="ourActive" v-for="item in list" :key="item.id" @click="toActive(item.id)">
                    <view class="main">
                        <view class="mcontent">
                            <view class="title">{{ item.title }}</view>
                            <view class="caption">{{ item.caption}}</view>
                            <view class="plain">{{ item.msg }}</view>
                        </view>
                        <!-- 有一处bug -->
                        <img src='../../static/images/huazhan.jpg' alt="" class="image"> 
                    </view>
                    <view class="descripe">
                        <text>艺品天下</text>
                        <text>查看全文>></text>
                    </view>
                </view>
            <!-- 推荐作品 -->
                <view class="works">
                    <image class="recommend" v-for="item in gallery" :src="item.url" :key="item.id" @click="toWorks(item.id)">
                        <view class="title">{{ item.title }}</view>
                        <view class="discripe">
                            <view>{{ item.discripe }}</view>
                            <view>{{ item.price }}</view>
                        </view>
                    </image>
                </view>
                <view @click="hhhh">点我</view>
                <uni-load-more status="loading" class="loadd" ref=sccc></uni-load-more>
            </swiper-item>
<!-- 其他 -->
            <swiper-item>
                <div  class="bg-white padding margin text-center text-black alll">
                    
                </div>
            </swiper-item>
            <swiper-item>
                <div  class="bg-white padding margin text-center text-black alll">兔子3</div>
            </swiper-item>
            <swiper-item>
                <div  class="bg-white padding margin text-center text-black alll">兔子4</div>
            </swiper-item>
            <swiper-item>
                <div  class="bg-white padding margin text-center text-black alll">兔子5</div>
            </swiper-item>
            <swiper-item>
                <div  class="bg-white padding margin text-center text-black alll">兔子6</div>
            </swiper-item>
            <swiper-item>
                <div  class="bg-white padding margin text-center text-black alll">兔子7</div>
            </swiper-item>
            <swiper-item>
                <div  class="bg-white padding margin text-center text-black alll">兔子8</div>
            </swiper-item>
        </swiper>
    </view>
    </view>
</template>
<script>
import WucTab from '@/components/wuc-tab/wuc-tab'
import uniLoadMore from "@/components/uni-load-more/uni-load-more.vue"
import { obj2style } from '@/common/utils.js';
    export default {
        components: {
            WucTab,
            uniLoadMore
        },
        data() {
        return {
            load:true,
             tabList4: [
                { name: '优选' },
                { name: '油画/丙烯' },
                { name: '水彩' },
                { name: '国画' },
                { name: '雕塑/装置' },
                { name: '版画' },
                { name: '书法' },
                { name: '古玩' }
            ],
            dotStyle: true,
            TabCur4: 0,
            cardCur: 0,
            swiperList: [],
            towerStart: 0,
            direction: '',
            list: [],
            gallery:[]
        }
    },
    computed: {
        CustomBar() {
            let style = {};
            // #ifdef MP-WEIXIN
            const systemInfo = uni.getSystemInfoSync();
            let CustomBar =
              systemInfo.platform === "android"
                ? systemInfo.statusBarHeight + 50
                : systemInfo.statusBarHeight + 45;
            style['top'] = CustomBar + 'px';
            // #endif
            // #ifdef H5
            style['top'] = 0 + 'px';
            // #endif
            return obj2style(style);
        }
    },
    methods: {
        // 搜索页
        searchNavigato() {
            uni.navigateTo({
                url: '/pages/main/search/search'
            })
        },
        // 扫码页
        toScanQR() {
            uni.navigateTo({
                url: '/pages/main/ScanQR/ScanQR'
            });
        },
        toBangdan(num) {
            uni.navigateTo({
                url: '/pages/main/bangdan/bangdan?id='+num
            });
        },
        toActive(id) {
            uni.navigateTo({
                url: '/pages/main/article/article?id='+id
            });
        },
        toWorks(id) {
            uni.navigateTo({
                url: '/pages/main/works/works?id='+id
            });
        },
        swiperChange4(e) {
            let { current } = e.target;
            this.TabCur4 = current;
        },
        hhhh(e){
            console.log(e)
            if(e.target.y >= uni.upx2px(1090)){
                e.offsetTop = uni.upx2px( 3000)
            }
        }
    },
    onLoad: function(e) {
        this.gallery = this.$store.state.gallery;
        this.swiperList = this.$store.state.swiperList;
        this.list = this.$store.state.listActive;
        console.log("监听页面加载，其参数为上个页面传递的数据")
    },
    onShow: function(e) {
        console.log("监听页面显示")
    },
    onReady: function(e) {
        console.log("监听页面初次渲染完成 ")
    },
    onHidden: function(e) {
        console.log("监听页面隐藏")
    }
}
/**
 * 调用state的数据
 * this.$store.state.名字
 * 
 * 调用mutations中的方法
 * this.$store.commit("getGallery");
 * 传参数最多有两个参数 可以为对象 数组
 * this.$store.commit("getGallery",{})
 *
 * getters只负责提供数据 不负责修改 对数据进行加工装饰包装
 */
</script>
<style lang="scss">
 .loadd{
    width: 750upx;
    height: 100upx;
 }
/* 全局 */
    * {
        margin: 0;
        padding: 0
    }
    .body {
        height:100%;
        background-color: #fff;
    }
/* 搜索框 */
    .searchl {
        width: 678upx;
        height: 66upx;
        margin: 18upx 0 8upx 36upx;
        background-color: #CDCDCD;
        border-radius: 10upx;
        display: flex;
        justify-content: space-between;
        .icon1 {
            width: 50upx;
            height: 66upx;
            line-height: 66upx;
            padding-left: 20upx;
            font-size: 36upx;
        }
        .search {
            width: 540upx;
            height: 66upx;
            font-size: 30upx;
        }
        .icon2 {
            width: 50upx;
            height: 66upx;
            margin-left: 20upx;
            line-height: 66upx;
            font-size: 36upx;
        }
        
    }
/* list */
    .mylist {
        width: 678upx;
        height: 4050upx;
        margin: 0;
        margin-left: 36upx;
        swiper {
            width:100%;
            height:370;
            .listContent {
                width: 678upx;
                height: auto;
            }
        }
    }
     .alll,swiper {
        box-sizing: border-box;
    }
    .alll {
      font-size: 36upx;
      background-color: #fff;
    }
    .swiper {
        height: 100%;
    }
    .cu-bar {
        display: flex;
        position: relative;
        align-items: center;
        min-height: 100upx;
        justify-content: space-between;
    }
    .cu-bar .action {
        display: flex;
        align-items: center;
        height: 100%;
        justify-content: center;
        max-width: 100%;
        background-color: #ffffff;
    }
    .listContent {
        width: 100%;
        min-height: 300upx;
    }
    .cu-bar .action:first-child {
        font-size: 36upx;
    }
    .solid,
    .solid-bottom {
        position: relative;
    }
    .solid::after,
    .solid-bottom::after{
        content: " ";
        width: 200%;
        height: 200%;
        position: absolute;
        top: 0;
        left: 0;
        border-radius: inherit;
        transform: scale(0.5);
        transform-origin: 0 0;
        pointer-events: none;
        box-sizing: border-box;
    }

    .solid::after {
        border: 1upx solid rgba(0, 0, 0, 0.1);
    }

    .solid-bottom::after {
        border-bottom: 1upx solid rgba(0, 0, 0, 0.1);
    }

    .text-orange{
      color:#f37b1d
    }
    .text-black{
      color:#333333;
    }
    .bg-white{
        background-color: #ffffff;
    }

    .padding {
        padding: 0upx;
    }

    .margin {
        margin: 0upx;
    }

    .margin-top {
        margin-top: 30upx;
    }
    .text-center {
        text-align: center;
    }  
/* /中心轮播/ */
swiper .a-swiper-dot {
    display: inline-block;
    width: 50upx;
    height: 50upx;
    background: rgba(0, 0, 0, .3);
    border-radius: 50%;
    vertical-align: middle;
    }

    swiper[class*="-dot"] .wx-swiper-dots,
    swiper[class*="-dot"] .a-swiper-dots,
    swiper[class*="-dot"] .uni-swiper-dots {
        display: flex;
        align-items: center;
        width: 100%;
        justify-content: center;
    }

    swiper.square-dot .wx-swiper-dot,
    swiper.square-dot .a-swiper-dot,
    swiper.square-dot .uni-swiper-dot {
        background-color: var(--white);
        opacity: 0.4;
        width: 10upx;
        height: 10upx;
        border-radius: 20upx;
        margin: 0 8upx !important;
    }

    swiper.square-dot .wx-swiper-dot.wx-swiper-dot-active,
    swiper.square-dot .a-swiper-dot.a-swiper-dot-active,
    swiper.square-dot .uni-swiper-dot.uni-swiper-dot-active {
        opacity: 1;
        width: 30upx;
    }
    swiper.round-dot .wx-swiper-dot,
    swiper.round-dot .a-swiper-dot,
    swiper.round-dot .uni-swiper-dot {
        width: 10upx;
        height: 10upx;
        position: relative;
        margin: 0upx 8upx !important;
    }
    .screen-swiper {
        height: 370upx;
    }
    .screen-swiper image,
    .screen-swiper video,
    .swiper-item image,
    .swiper-item video {
        width: 100%;
        display: block;
        height: 100%;
        margin: 0;
        pointer-events: none;
    }
/* 榜单 */
    .listOfName {
        width: 100%;
        height: 140upx;
        margin: 30upx 0;
        box-sizing: border-box;
        display:flex;
        .list {
            width:162.5upx;
            height: 100%;
            text-align:left;
            .tu {
                width: 90upx;
                height: 90upx;
                border-radius: 50%;
            }
            .zi {
                box-sizing: border-box;
                width: 135.6upx;
                height: auto;
                font-size: 20upx;
            }
        }
        :nth-of-type(1){
            .zi{
                padding-left: 10upx;
            }
        }
        :nth-of-type(2){
            .zi{
                padding-left: 14upx;
            }
        }
        :nth-of-type(3){
            .tu {
                border-radius: 50%;
            }
            .zi{
                padding-left: 16upx;
            }
        }
         :nth-of-type(4){
            .zi{
                padding-left: 10upx;
            }
        }
        :nth-of-type(5){
            width: 90upx;
            text-align: center;
            .zi{
                width:90upx;
                padding-left: 0upx;
            }
        }  
    }
/* 我们的活动 */
    .ourActive {
        width: 672upx;
        height:320upx;
        box-sizing: border-box;
        box-shadow: 6upx 6upx 4upx rgba(51,51,51,.3);
        border-radius: 6upx;
        padding: 36upx 18upx 0;
        .main {
            width: 100%;
            height: 224upx;
            display: flex;
            .mcontent {
                width: 376upx;
                height: 224upx;
                overflow: auto;
                margin-right: 28upx;
                .title {
                    height: 56upx;
                    width: 100%;
                    font-size: 29upx;
                    font-weight: 700;
                }
                .caption {
                    height: 56upx;
                    width: 100%;
                    font-size: 25.5upx;
                    text-align: left;
                    font-weight: 700;
                }
                .plain {
                    height: 112upx;
                    width: 100%;
                    text-indent: 2em;
                    font-size: 25upx;
                }
            }
            .image {
                width: 232upx;
                height: 224upx;
            }
        }
        .descripe {
            width: 100%;
            height: 60upx;
            box-sizing: border-box;
            padding-top: 10upx;
            position: relative;
            :nth-of-type(1) {
                height: 50upx;
                width: 150upx;
                line-height: 50upx;
                font-size: 24upx;
                position: absolute;
                left: 0;
            }
            :nth-of-type(2) {
                height: 50upx;
                width: 130upx;
                line-height: 50upx;
                font-size: 24upx;
                position: absolute;
                right: 0;
            }
        }
    }
/* 推荐 */
    .works {
        width:678upx;
        height: auto;
        padding-top: 20upx;
        .recommend {
            width: 678upx;
            height: 400upx;
            box-sizing: border-box;
            margin-bottom: 10upx;
            border-radius: 10upx;
            position: relative;
            .title {
                width: 200upx;
                height: 50upx;
                position: absolute;
                font-size: 32upx;
                line-height: 50upx;
                color: white;
                top: 290upx;
                left: 38upx;
            }
            .discripe {
                width: 630upx;
                height: 40upx;
                position: absolute;
                top: 345upx;
                left: 38upx;
                :nth-of-type(1){
                    width:360upx;
                    height: 40upx;
                    line-height: 40upx;
                    position: absolute;
                    font-size: 26upx;
                    color: white;
                    top: 0;
                    left: 0;
                }
                :nth-of-type(2) {
                    width:210upx;
                    height: 40upx;
                    position: absolute;
                    font-size: 30upx;
                    color: white;
                    text-align: right;
                    line-height: 40upx;
                    top: 0;
                    right: 0;
                }
            }
        }
        .recommend:last-child {
        }
    }

</style>
