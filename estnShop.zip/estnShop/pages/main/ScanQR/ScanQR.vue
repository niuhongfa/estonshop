<template>
	  <view class="body">
        <button @click="getimage" class="getimage">获取相册相片</button>
        <img :src="srci" class="getimage"/>
        <!--  此处的视频可以调用摄像头录视频   -->
         <button @tap="test" class="getimage">click me</button>  
        <video :src="src" class="getimage"></video>
        <input type="file" class="getimage"/>
        <button @click="getImages">活该</button>

    </view>
</template>

<script>
	export default {
	    data() {
	        return {
	            srcl:"",
	            src:""
	        }
	    },
	    computed:{
	    	srci(){
	    		return this.srcl
	    	}
	    },
	    methods: {
	        getimage(){
	        	uni.chooseImage({
				    count: 6, //默认9
				    sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
				    sourceType: ['album'], //从相册选择
				    success: function (res) {
				        console.log(JSON.stringify(res.tempFilePaths));
				        this.srcl = (res.tempFilePaths)
				        console.log(this.srcl)
				    }
				}); 
	        },
	        test: function () {
	            var self = this;
	            uni.chooseVideo({
	                count: 1,
	                sourceType: ['camera', 'album'],
	                success: function (res) {
	                    self.src = res.tempFilePath;
	                }
	            });
	        },
	        getCar(){
	        },
	        getImages() {      
	        	// #ifdef APP-PLUS
		       var cmr = plus.camera.getCamera();    
		       cmr.captureImage(function(p) {    
		           plus.io.resolveLocalFileSystemURL(p, function(entry) { 
		               plus.zip.compressImage(entry.toLocalURL(),entry.name);
	               entry.file( function(file){ 
		console.log(1) 
		               var fileReader = new plus.io.FileReader();  
		               fileReader.readAsDataURL(file);  
		               fileReader.onloadend = function(e) { 
		console.log(2) 
			 
		                    var picUrl = e.target.result.toString(); 
							console.log(picUrl+"=====")
		               }  
		           });
					           }, function(e) {    
		               plus.nativeUI.toast("读取文件错误：" + e.message);    
		           });    
		       }, function(e) {    
		       }, {    
		           filter: 'image'   
		       });  
			// #endif  
			   }
	    },
	    onLoad(e){
	    	this.getCar()
	    }
	}
</script>

<style lang="scss">
 .getimage{
 	width: 600upx;
 	height: 200upx;
 	background-color: pink;
 }
.image{
	width:500upx;
	height: 500upx;
	background-color: orangered;
}
</style>
