<!-- 注册 -->
<template>
   <view class="body">
        <view class="mainarea">
           <view class="discripe">注册</view>
           <view class="user"> 
                <text class="iicol iconfont icon-shouji"></text>
                <input type="text" placeholder="请输入账号或手机号" name="username" maxlength="11" class="iicot" v-model="phone">
            </view>

            <view class="pass">
                <text class="iicol iconfont icon-xiugaimima"></text>
                <input type="text" placeholder="请输入密码" name="password" class="iict" maxlength="18" v-model="password">
                <text class="iicz iconfont icon-biyan"></text>
           </view>

            <view class="pass">
                <text class="iicoll iconfont icon-shimingrenzheng"></text>
                <input type="text" placeholder="请输入验证码" name="password" class="iictv" maxlength="18" v-model="verify">
                <button class="verification">获取验证码</button>
           </view>

            <button type="primary" class="login" @click="register">完成</button> 
        </view>
        <navigator class="register" url="../login/login">
            已注册，去登录
        </navigator>
        
    </view>
</template>

<script>
    import service from '../../service.js';
    export default {
        components: {
        },
        data() {
            return {
                phone: '',
                password: '',
                verify: ''
            }
        },
        methods: {
            register() {
                /**
                 * 客户端对账号信息进行一些必要的校验。
                 * 实际开发中，根据业务需要进行处理，这里仅做示例。
                 */
                
                if (this.phone.length < 9) {
                    uni.showToast({
                        icon: 'none',
                        title: '账号最短为 5 个字符'
                    });
                    return;
                }
                if (this.password.length < 6) {
                    uni.showToast({
                        icon: 'none',
                        title: '密码最短为 6 个字符'
                    });
                    return;
                }
                uni.setStorage({
                    key: this.phone,
                    data: {
                        phone: this.phone,
                        password: this.password
                    }
                })
                uni.showToast({
                    title: '注册成功'
                });
                uni.navigateBack({
                    delta: 1
                });
            }
        }
    }
</script>

<style>
 .body {
        width: 750upx;
        height: 1246upx;
        box-sizing: border-box;
        padding: 210upx 65upx 0;
        background-color: orangered;
    }
    .body>.mainarea {
        width: 620upx;
        height: 690upx;
        box-sizing: border-box;
        background-color: #fff;
        border-radius: 25upx;
        padding-top: 40upx;
    }
    .body>.register {
        width: 250upx;
        height: 50upx;
        font-size: 28upx;
        color: white; 
        text-align: center;
        margin: 70upx 0 0 185upx;
    }
    .body>.forget {
        width: 120upx;
        height: 50upx;
        font-size: 28upx;
        color: white;
        text-align: center;
        margin: 72upx 0 0 490upx;
    }
    .login {
        width: 440upx;
        height:64upx;
        margin-top: 80upx;
        background-color: #C63F1A;
        line-height: 64upx;
    }
    .discripe {
        width: 90upx;
        height: 50upx;
        font-size: 40upx;
        font-weight: 700;
        margin: 0 auto;
    }
    .user {
        width:480upx;
        height:120upx;
        display:flex;
        margin: 40upx auto 0;
        border-bottom: 2upx solid #ccc;
    }
    .iicol {
        width: 60upx;
        height: 60upx;
        margin: auto 10upx;
        margin-left: 0;
        font-size: 60upx;
    }
    .user>.iicot {
        width: 390upx;
        height: 60upx;
        margin: auto 0;
        box-sizing: border-box;
        padding-left: 10upx;
    }
    .pass {
        width:480upx;
        height:120upx;
        margin: 0 auto;
        display:flex;
        border-bottom: 2upx solid #ccc;
    }
    .pass>.iict {
        width: 340upx;
        height: 60upx;
        margin: auto 0;
        margin-right: 10upx;
        box-sizing: border-box;
        padding-left: 10upx;
    }
    .pass>.iicz {
         width: 60upx;
        height: 60upx;
        margin-top: 40upx;
        font-size: 40upx; 
    }
    .iicoll {
        width: 60upx;
        height: 60upx;
        margin: auto 0upx;
        margin-left: 10upx;
        font-size: 50upx;
    }
    .iictv {
        width:215upx;
        height:60upx;
        margin: auto 0;
        margin-right: 10upx;
        box-sizing: border-box;
        padding-left: 10upx;
        font-size:35upx;
    }
    .verification {
        width:190upx;
        height:60upx;
        line-height: 60upx;
        margin-top: 30upx;
        padding: 0;
        font-size: 32upx;
        color: red;
        background-color: #fff;
    }
</style>
