			
	export {
			//document.addEventListener( "plusready", onPlusReady, false );
				// 扩展API加载完毕，现在可以正常调用扩展API
				function onPlusReady() {
				    var e = document.getElementById("scan");
				    e.removeAttribute( "disabled" );
				}
				var scan = null;
				function onmarked( type, result ) {
				    var text = '未知: ';
				    switch(type){
				        case plus.barcode.QR:
				        text = 'QR: ';
				        break;
				        case plus.barcode.EAN13:
				        text = 'EAN13: ';
				        break;
				        case plus.barcode.EAN8:
				        text = 'EAN8: ';
				        break;
				    }
				    alert( text+result );
				}
				function startRecognize() {
				    scan = new plus.barcode.Barcode('bcid');
				    scan.onmarked = onmarked;
				}
				function startScan() {
				    scan.start();
				}
				function cancelScan() {
				    scan.cancel();
				}
				function setFlash() {
				    scan.setFlash();
				}
			}