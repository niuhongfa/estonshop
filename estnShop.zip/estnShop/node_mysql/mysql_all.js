const mysql = require("mysql");
 class Connect{
	constructor(HOST,USER,PASS,PORT,DATABASE,CHARSET){
		this.host = HOST ? HOST : 'localhost';
		this.user = USER ? USER : "root";
		this.pass = PASS ? PASS : 'root';
		this.port = PORT ? PORT : '3306';
		this.database = DATABASE ? DATABASE : 'yiston';
		this.charset = CHARSET ? CHARSET : 'utf-8';
	}
	con(){
		let con = mysql.createConnection({
			host : this.host,
			user : this.user,
			pass : this.pass,
			port : this.port,
			charset : this.charset,
			database : this.database
		})
		con.connect();
		con.query("SELECT 1 + 1 AS solution",function(err,res,fields){
			if(err) return err;
			console.log("the solution is :",results[0].solution)
		})
	}
}
let all = new Connect()
module.exports = {
	all()
}