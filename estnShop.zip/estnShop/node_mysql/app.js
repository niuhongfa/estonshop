const http = require("http");
const mysql = require("mysql");
const my = require('./mysql_all')
const server = http.createServer();
server.on("request",function(req,res){


	res.setHeader("content-type","text/plain;charset=utf-8")
	res.end("哈喽!hahha?chenggongle")
})
server.listen(3000,function(){
	console.log("大神服务器正在启动中...")
})