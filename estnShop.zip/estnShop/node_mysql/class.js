const fs = require("fs");
const path = require("path")
const http = require("http")
const mysql = require("mysql")


/**
 * 1 初步认识class
 * 2 话不多收看下边的代码
 * 3 代码规范 每个文件的结尾 多一个空格结尾
 * 
 */
	// class Person{
	// 	constructor(name,age){
	// 		this.name = name;
	// 		this.age = age;
	// 	}
	// 	say(){
	// 		return "my name is"+this.name+"i am "+this.age+"years old s"
	// 	}
	// }
	// let sl = new Person("XueEr",18)
	// console.log(sl.say())
	// http.createServer()
	// .on("request",function(req,res){
	// 	res.end(sl.say())
	// })
	// .listen(5000,function(){
	// 	console.log("服务器正在启动中...")
	// })

/**
 *
 * class 创建的函数 不存在变量的提升
 */
// class Man{
// 	constructor(a,b){
// 		this.numone = a;
// 		this.numtwo = b;
// 	}
// 	add(){
// 		return this.numone + this.numtwo;
// 	}
// 	jian(){
// 		return this.numone - this.numtwo;
// 	}
// 	cheng(){
// 		return this.numone * this.numtwo;
// 	}
// 	chu(){
// 		return this.numone / this.numtwo;
// 	}
// }
// let lv = new Man(9,4);
// console.log(lv.add())
// console.log(lv.cheng())
// console.log(lv.chu())
// console.log(lv.jian())
// http.createServer()
// 	.on("request",function(req,res){
// 		res.end("运行中")
// 	})
// 	.listen(5000,function(){
// 		console.log("服务器正在启动中...")
// 	})
// 	
/**
 * class 静态方法
 * static 
 *
 * super 关键字是访问父对象上的函数
 * super可以用在类的继承中，或者对象字面量中，super指代了整个prototype或者__proto__指向的对象
 *
 *
 * super用在调用的时候有两种情况：
第一种情况，super作为函数调用时，代表父类的构造函数。
第二种情况，super作为对象时，在普通方法中，指向父类的原型对象；在静态方法中，指向父类

super 关键字用于调用一个对象的父对象上的函数。
super.prop 和 super[expr] 表达式在类 和 对象字面量 任何 方法定义 中都是有效的。
在构造函数中使用时，super关键字单独出现，必须在可以使用this关键字之前使用。此关键字也可用于调用父对象上的函数。
 **
 *类相当于实例的原型， 所有在类中定义的方法， 都会被实例继承。 如果在一个方法前， 加上static关键字， 就表示该方法不会被实例继承， 而是直接通过类来调用， 这就称为“ 静态方法”。

静态方法调用直接在类上进行，而在类的实例上不可被调用。

静态方法通常用于创建 实用/工具 函数。
 * 
 */
/**
 * node 不支持es6的私有属性和方法
 */

class Foo {
  static classMethod() {
    return 'hello';
  }
}

class Bar extends Foo {
  static classMethod() {
  	console.log(super.classMethod)
    return super.classMethod() + ', too';
  }
}

let lla = Bar.classMethod()
console.log() 

 class Data{
 	this._count = 0
 	constructor(a,b){
 		this.a = a;
 		this.b = b;
 	}
 	add(){
 		return this.a + this.b
 	}
 	say(){
 		return this._count;

 	}
 	static al(){
 		console.log("lalalala")
 		return this.a * this.b
 	}
 }

 let func = new Data()

console.log( func.say() )


let ad = Data.al()

console.log(ad)
  http.createServer(ad)
  .on("request",function(req,res){
  	res.end(req.url)//   /
  })
  .listen(5000,function(){
  	console.log("大神服务器进行中...")
  })