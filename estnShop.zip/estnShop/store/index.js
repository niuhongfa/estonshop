import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
    state: { // 存储公共信息
        /**
         * 是否需要强制登录
         */
        forcedLogin: false,
        hasLogin: false,
        isenter: false,
        user: "",
        pass: "",
        phone: "",
        ldata: "",
        entermsg:{},
        gallery: [ // 推荐商品
         {
                    "id":"1","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin.jpg"
                },
                {
                    "id":"2","title":"深海传说","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin2.jpg"
                },
                {
                    "id":"3","title":"亚历山大","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin3.jpg"
                },
                {
                    "id":"4","title":"深海传说","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin2.jpg"
                },
                {
                    "id":"5","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin.jpg"
                },
                {
                    "id":"6","title":"某大人物","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin3.jpg"
                },
                {
                    "id":"7","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin.jpg"
                },
                {
                    "id":"8","title":"深海传说","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin2.jpg"
                },
                {
                    "id":"9","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin.jpg"
                },
                {
                    "id":"10","title":"某大人物","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin3.jpg"
                },
                {
                    "id":"11","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin.jpg"
                },
                {
                    "id":"12","title":"深海传说","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin2.jpg"
                },
                {
                    "id":"13","title":"亚历山大","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin3.jpg"
                },
                {
                    "id":"14","title":"深海传说","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin2.jpg"
                },
                {
                    "id":"15","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin.jpg"
                },
                {
                    "id":"16","title":"某大人物","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin3.jpg"
                },
                {
                    "id":"17","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin.jpg"
                },
                {
                    "id":"18","title":"深海传说","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin2.jpg"
                },
                {
                    "id":"19","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin.jpg"
                },
                {
                    "id":"20","title":"某大人物","discripe":"油画/30×60cm/2018","price":"￥3000.00","url":"../../static/images/zuopin3.jpg"
                }
            ],
            commentlist: [ // 评论列表
                {
                    "id":"1","name":"张三","content":"她是个傻子吧","nowdate":"2019-06-01 13:14:52","avatar":"头像"
                },{
                    "id":"2","name":"张三","content":"她是个傻子吧","nowdate":"2019-06-01 13:14:52","avatar":"头像"
                },{
                    "id":"3","name":"张三","content":"她是个傻子吧","nowdate":"2019-06-01 13:14:52","avatar":"头像"
                },{
                    "id":"4","name":"张三","content":"她是个傻子吧","nowdate":"2019-06-01 13:14:52","avatar":"头像"
                },{
                    "id":"5","name":"张三","content":"她是个傻子吧","nowdate":"2019-06-01 13:14:52","avatar":"头像"
                }
            ],
            bought: [ // 已购买
                {
                    "id":"1","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"商品图"
                },{
                    "id":"2","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"上图"
                },{
                    "id":"3","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"拼图"
                }
            ],
            carlist: [ // 购物车
                 {
                    "id":"1","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"商品图","block":"0","allselect":"0"
                },{
                    "id":"2","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"上图","block":"0","allselect":"0"
                },{
                    "id":"3","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"拼图","block":"0","allselect":"0"
                },{
                    "id":"4","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"上图","block":"0","allselect":"0"
                },{
                    "id":"5","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"拼图","block":"0","allselect":"0"
                },{
                    "id":"6","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"上图","block":"0","allselect":"0"
                },{
                    "id":"7","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"拼图","block":"0","allselect":"0"
                },{
                    "id":"8","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"上图","block":"0","allselect":"0"
                },{
                    "id":"9","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"拼图","block":"0","allselect":"0"
                },{
                    "id":"10","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"上图","block":"0","allselect":"0"
                },{
                    "id":"11","pname":"甘蔗","puser":"李四","title":"这画不一般","discripe":"来自两千多年前的李白白所做","price":"99999","discount":"1","boughttime":"2019-06-01 08:08:08","image":"拼图","block":"0","allselect":"0"
                }
            ],
            collectshop:[  // 收藏列表
                {
                    "id":"5","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","book":"0","url":"../../static/images/zuopin.jpg"
                },{
                    "id":"2","title":"深海传说","discripe":"油画/30×60cm/2018","price":"￥3000.00","book":"1","url":"../../static/images/zuopin2.jpg"
                },{
                    "id":"3","title":"亚历山大","discripe":"油画/30×60cm/2018","price":"￥3000.00","book":"0","url":"../../static/images/zuopin3.jpg"
                },{
                    "id":"7","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","book":"1","url":"../../static/images/zuopin.jpg"
                },{
                    "id":"1","title":"江南水乡","discripe":"油画/30×60cm/2018","price":"￥3000.00","book":"0","url":"../../static/images/zuopin.jpg"
                }
            ],
        swiperList: [ // 首页lunbo
            {
                id: 0,
                type: 'image',
                url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big84000.jpg'
            }, {
                id: 1,
                type: 'image',
                url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big37006.jpg',
            }, {
                id: 2,
                type: 'image',
                url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big39000.jpg'
            }, {
                id: 3,
                type: 'image',
                url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big10001.jpg'
            }, {
                id: 4,
                type: 'image',
                url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big25011.jpg'
            }, {
                id: 5,
                type: 'image',
                url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big21016.jpg'
            }, {
                id: 6,
                type: 'image',
                url: 'https://ossweb-img.qq.com/images/lol/web201310/skin/big99008.jpg'
            }
            ],
        listActive: [ // 首页活动
            {"id":1,"title":"我们的活动","url":"../../../static/images/shuijiao.jpg","caption":"《参加画展》张之洞与武汉博物馆","msg":"行人就着夕阳望向长江,岸边是戏水打闹的小孩`青年`老人和猫狗老鼠兔子..."}
            ],
        listSearch: [
            {"id":1,"aid":"1","name":"用户1","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":2,"aid":"2","name":"作品1","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":3,"aid":"1","name":"用户2","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":4,"aid":"3","name":"文章2","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":5,"aid":"1","name":"用户3","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":6,"aid":"3","name":"文章3","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":7,"aid":"1","name":"用户5","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":8,"aid":"2","name":"作品3","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":9,"aid":"2","name":"作品5","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":10,"aid":"1","name":"用户7","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":11,"aid":"3","name":"文章10","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":12,"aid":"2","name":"作品31","url":"../../../static/images/qrcode.png","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":13,"aid":"1","name":"用户22","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":14,"aid":"3","name":"文章22","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":15,"aid":"1","name":"用户13","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":16,"aid":"3","name":"文章113","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":17,"aid":"1","name":"用户15","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":18,"aid":"2","name":"作品13","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":19,"aid":"2","name":"作品15","url":"../../../static/images/muwu.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":20,"aid":"1","name":"用户17","url":"../../../static/images/yuantiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
            {"id":21,"aid":"3","name":"文章110","url":"../../../static/images/shuijiao.jpg","msg":"他真的很漂亮,嗯,很漂亮的小李","ctime":new Date(),"usg":"wawawwawawwawawawa"},
        ],
        youraddress: [
            {
                "id":"1","uname":"牛莹莹","phonenum":"15578488111","uaddress":"河南省新乡市长垣县","waddress":"武邱乡牛庄村001号","checked":true
            },{
                "id":"2","uname":"张嘉欣","phonenum":"15578488333","uaddress":"河南省新乡市长垣县","waddress":"武邱乡张庄村001号","checked":false
            },{
                "id":"3","uname":"刘莹莹","phonenum":"15578488555","uaddress":"河南省新乡市长垣县","waddress":"武邱乡刘庄村001号","checked":false
            }
        ],
        informationfromlist: [
            {
                "id":"1","from":"张过劳","phone":"16639733366","msg":["吃饭了吗?","你在干嘛呢","喜欢我吗","最近有空吗","咳咳","借点钱怎么样啊","不多","1000"],"ctime":"00:00","url":"../../static/img/qq.png"
            },{
                "id":"2","from":"张过劳","phone":"16639733366","msg":["吃饭了吗?","你在干嘛呢","喜欢我吗","最近有空吗","咳咳","借点钱怎么样啊","不多","1000"],"ctime":"00:00","url":"../../static/img/qq.png"
            },{
                "id":"3","from":"张过劳","phone":"16639733366","msg":["吃饭了吗?","你在干嘛呢","喜欢我吗","最近有空吗","咳咳","借点钱怎么样啊","不多","1000"],"ctime":"00:00","url":"../../static/img/qq.png"
            }
        ],
        informationsendlist: [
            {
                "id":"1","send":"张过劳","phone":"16639733366","msg":["没?","干什么","不","有空","咳咳","你说啥","多","1块"],"time":"00:01"
            },{
                "id":"1","send":"张过劳","phone":"16639733366","msg":["哦?","没干什么","你猜","没","呵呵","en?","不多","0块"],"time":"00:01"
            },{
                "id":"1","send":"张过劳","phone":"16639733366","msg":["啊???","你猜","对","你猜","你猜","你猜","真的多","-1000块"],"time":"00:01"
            }
        ]
    },
    getters: {  //监听state变化
        getvip(state){
            store.commit("getenter")
            return state.isenter
        }
    },
    mutations: { // 操作state的方法 不允许异步
        // 是否登陆
        login(state, user) {   // 已登录
            state.user = user ;
            state.hasLogin = true;
        },
        logindown(state){   // 未登录
            state.hasLogin = false;
        },
        // 登陆传值判断账户的正确性
        getKey(state,key){
            state.phone = key;
            console.log((state.phone))
            console.log("diaoyongle"+"==="+key)
        },
        getuserpass(state) {
            uni.getStorage({
                key: state.phone,
                success(e){
                    let data = e.data;
                    state.user = data.user;
                    state.pass = data.password;
                    state.phone = data.phone;
                    console.log(data)
                },
                fail: function(err) {
                    console.log(state.phone+"该手机号未注册")
                }
            })
        },
        getenter(state){
            uni.getStorage({
                key:"isvip",
                success(e){
                    if(parseInt(e.data.vip) === 1){
                        state.isenter = true
                    }
                }
            })
        },
        // 添加收货地址
        changeyouraddress(state,data){
            console.log(data);
            state.youraddress.push(data);
            console.log(state.youraddress);
        },
        // 修改收货地址
        setyouraddress(state,data){
            let index = state.youraddress.findIndex(item => {
                if(data.id === item.id){
                    return item
                }
            });
            state.youraddress.splice(index,1,data)
        },
        // 删除收货地址
        deladdress(state,id){
            let index = state.youraddress.findIndex(item => {
                if(item.id === id){
                    return item;
                }
            });
            state.youraddress.splice(index,1)
        },
        // 取消收藏
        delcollect(state,id){
            let index = state.collectshop.findIndex(item => {
                if(item.id === id){
                    return item
                }
            });
            state.collectshop.splice(index,1)
        },
        // 删除对话
        delFromInformation(state,id) {
            let index = state.informationfromlist.findIndex(item => {
                if(item.id == id){
                    return item;
                }
            });
            state.informationfromlist.splice(index,1)
        },
        // 删除发送消息 => 可改变为撤销发送
        delFromInformation(state,{id,it}) {
            let iitem = state.informationsendlist.find(item => {
                if(item.id == id){
                    return item;
                }
            });
            let index = iitem.findIndex(item => {
                if(iitem[item] == it){
                    return item
                }
            });
            state.informationfromlist.splice(index,1)
        },
        setentermsg(state,{val}){}
    },
    actions: { // 可以异步

     }
})

export default store
