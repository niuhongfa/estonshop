import Vue from 'vue'
import App from './App'
import store from './store'
import './static/iico-icon/iconfont.css'
import './static/js/json2.js'
Vue.config.productionTip = false

Vue.prototype.$store = store

App.mpType = 'app'

const app = new Vue({
    store,
    ...App
})
app.$mount()
